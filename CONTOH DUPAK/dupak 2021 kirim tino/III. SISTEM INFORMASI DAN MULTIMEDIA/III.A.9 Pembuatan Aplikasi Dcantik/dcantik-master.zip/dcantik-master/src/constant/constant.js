// export const url_api = "http://localhost/dcantik-api/api.php";
// export const url_login = "http://localhost/dcantik-api/api/login.php";
// export const url_rekapitulasi = "http://localhost/dcantik-api/rekapitulasi.php";
// export const url_rekapitulasi_chart = "http://localhost/dcantik-api/rekapitulasi_chart.php";
// export const url_download_template = "http://localhost/dcantik-api/template-isian-dcantik.xlsx";

// export const url_api = "https://sultradata.com/project/dcantik-api/api.php";
// export const url_login = "https://sultradata.com/project/dcantik-api/api/login.php";
// export const url_rekapitulasi = "https://sultradata.com/project/dcantik-api/rekapitulasi.php";
// export const url_rekapitulasi_chart = "https://sultradata.com/project/dcantik-api/rekapitulasi_chart.php";
// export const url_download_template = "https://sultradata.com/project/dcantik-api/template-isian-dcantik.xlsx";

export const url_api = "https://mandonga.kendarikota.go.id/dcantik-api/api.php";
export const url_login = "https://mandonga.kendarikota.go.id/dcantik-api/api/login.php";
export const url_rekapitulasi = "https://mandonga.kendarikota.go.id/dcantik-api/rekapitulasi.php";
export const url_rekapitulasi_chart = "https://mandonga.kendarikota.go.id/dcantik-api/rekapitulasi_chart.php";
export const url_download_template = "https://mandonga.kendarikota.go.id/dcantik-api/template-isian-dcantik.xlsx";

export const isLogin = () => {
    let storage = localStorage.getItem("dcantik_state");
    if (storage !== null) {
        let temp = JSON.parse(storage);
        let currentDate = new Date();
        let prevDate = Date.parse(temp.date);
        let diff = Math.abs(currentDate - prevDate) / 3600000; //get hours difference
        // console.log(diff);
        if (diff <= 2) {
            return true;
        }
        return false;
    }
}

export const getAuthData = () => {
    let storage = localStorage.getItem("dcantik_state");
    if (storage !== null) {
        let temp = JSON.parse(storage);
        return temp;
    }
    return null;
}