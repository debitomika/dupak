import React from "react";
import ReactDataGrid from "react-data-grid";
// import "./styles.css";
import { Editors } from "react-data-grid-addons";
// import 'react-datepicker/dist/react-datepicker-cssmodules.css';
import ColorEditor from "../components/DateEditor";
import CleaveEditor from "../components/CleaveEditor";
import { url_api, url_download_template } from "../constant/constant";
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import { getAuthData } from '../constant/constant';
import { Menu } from "react-data-grid-addons";
import * as Yup from "yup";
import DateEditorNew from "../components/DateEditorNew";
import IconButton from '@material-ui/core/IconButton';
import RefreshIcon from '@material-ui/icons/Refresh';
import {json2excel, excel2json} from 'js2excel';

const { ContextMenu, MenuItem, SubMenu, ContextMenuTrigger } = Menu;

var dayjs = require('dayjs');
var customParseFormat = require('dayjs/plugin/customParseFormat');
dayjs.extend(customParseFormat)

const { DropDownEditor } = Editors;
const genderTypes = [
    { id: "laki-laki", value: "Laki-laki" },
    { id: "perempuan", value: "Perempuan" }
];
const GenderTypeEditor = <DropDownEditor options={genderTypes} />;

const bloodTypes = [
    { id: "A", value: "A" },
    { id: "B", value: "B" },
    { id: "O", value: "O" },
    { id: "AB", value: "AB" },
];
const BloodTypeEditor = <DropDownEditor options={bloodTypes} />;

const religionTypes = [
    { id: "Islam", value: "Islam" },
    { id: "Katolik", value: "Katolik" },
    { id: "Protestan", value: "Protestan" },
    { id: "Hindu", value: "Hindu" },
    { id: "Budha", value: "Budha" },
    { id: "Khonghucu", value: "Khonghucu" },
];
const ReligionTypeEditor = <DropDownEditor options={religionTypes} />;

const educationTypes = [
    { id: "tidak_sekolah", value: "Tidak Sekolah" },
    { id: "belum_sekolah", value: "Belum Sekolah" },
    { id: "TK", value: "TK" },
    { id: "SD", value: "SD" },
    { id: "SMP", value: "SMP" },
    { id: "SMA", value: "SMA" },
    { id: "DI", value: "DI" },
    { id: "DII", value: "DII" },
    { id: "DIII", value: "DIII" },
    { id: "DIV-S1", value: "DIV/S1" },
    { id: "S2", value: "S2" },
    { id: "S3", value: "S3" },
];
const EducationTypeEditor = <DropDownEditor options={educationTypes} />;

const familyTypes = [
    { id: "kepala_keluarga", value: "Kepala Keluarga" },
    { id: "suami", value: "Suami" },
    { id: "istri", value: "Istri" },
    { id: "anak_kandung", value: "Anak Kandung" },
    { id: "anak_angkat", value: "Anak Angkat" },
    { id: "ayah", value: "Ayah" },
    { id: "ibu", value: "Ibu" },
    { id: "lainnya", value: "lainnya" },
];
const familyTypeEditor = <DropDownEditor options={familyTypes} />;

const marriedStatusTypes = [
    { id: "belum_kawin", value: "Belum Kawin" },
    { id: "kawin", value: "Kawin" },
    { id: "tidak_kawin", value: "Tidak Kawin" },
];
const MarriedStatusTypeEditor = <DropDownEditor options={marriedStatusTypes} />;

const KBTypes = [
    { id: "tidak_kb", value: "Tidak KB" },
    { id: "kb_suntik", value: "KB Suntik" },
    { id: "kb_spiral", value: "KB Spiral" },
    { id: "kb_kondom", value: "KB Kondom" },
    { id: "kb_pil", value: "KB Pil" },
    { id: "kb_alami", value: "KB Alami" },
    { id: "kb_lainnya", value: "KB Lainnya" },
];
const KBStatusTypeEditor = <DropDownEditor options={KBTypes} />;

const disabiltasTypes = [
    { id: "tanpa_disablitas", value: "Tanpa Disabilitas" },
    { id: "tuna_rungu", value: "Tuna Rungu" },
    { id: "tuna_wicara", value: "Tuna Wicara" },
    { id: "tuna_netra", value: "Tuna Netra" },
    { id: "lumpuh", value: "Lumpuh" },
    { id: "sumbing", value: "Sumbing" },
    { id: "idiot", value: "Idiot" },
    { id: "gila", value: "Gila" },
    { id: "stress", value: "Stress" },
    { id: "disabilitas_lainnya", value: "Disabilitas Lainnya" },
];
const DisabilitasStatusTypeEditor = <DropDownEditor options={disabiltasTypes} />;

const statusRumahTypes = [
    { id: "milik_sendiri", value: "Milik sendiri" },
    { id: "milik_orang_tua", value: "Milik orang tua" },
    { id: "milik_keluarga", value: "Milik keluarga" },
    { id: "sewa_kontrak", value: "Sewa/Kontrak" },
    { id: "lainnya", value: "lainnya" },
];
const rumahStatusTypeEditor = <DropDownEditor options={statusRumahTypes} />;

const buktiRumahTypes = [
    { id: "sertifikat", value: "Sertifikat" },
    { id: "HGB", value: "HGB" },
    { id: "AJB", value: "AJB" },
    { id: "lainnya", value: "lainnya" },
];
const buktiRumahStatusTypeEditor = <DropDownEditor options={buktiRumahTypes} />;

const pbbTypes = [
    { id: "ada", value: "Ada" },
    { id: "tidak_ada", value: "Tidak Ada" },
];
const pbbStatusTypeEditor = <DropDownEditor options={pbbTypes} />;

const rumahTypes = [
    { id: "permanen", value: "Permanen" },
    { id: "semi_permanen", value: "Semi Permanen" },
];
const rumahTypeEditor = <DropDownEditor options={rumahTypes} />;

const sumberAirTypes = [
    { id: "pdam", value: "PDAM" },
    { id: "sumur", value: "Sumur" },
    { id: "sungai", value: "Sungai" },
    { id: "air_minum_kemasan", value: "Air Minum Kemasan" },
    { id: "lainnya", value: "Lainnya" },
];
const sumberAirTypeEditor = <DropDownEditor options={sumberAirTypes} />;

const peneranganTypes = [
    { id: "listrik_pln", value: "Listrik PLN" },
    { id: "listrik_numpang", value: "Listrik Numpang" },
    { id: "listrik_tidak_ada", value: "Tidak ada listrik" },
];
const peneranganTypeEditor = <DropDownEditor options={peneranganTypes} />;

const fasilitasTypes = [
    { id: "ada", value: "Ada" },
    { id: "tidak_Ada", value: "Tidak Ada" },
];
const fasilitasTypeEditor = <DropDownEditor options={fasilitasTypes} />;

const septicTankTypes = [
    { id: "ada", value: "Ada" },
    { id: "tidak_Ada", value: "Tidak Ada" },
    { id: "langsung_ke_sungai", value: "Langsung ke Sungai" },
];
const septicTankTypeEditor = <DropDownEditor options={septicTankTypes} />;


function detectMob() {
    return ( ( window.innerWidth <= 768 )  );
}

const columns = [
    { key: "no", name: "No", editable: false, frozen: !detectMob() },
    { key: "urut_kk", name: "No Urut KK", editable: true, width: 150, frozen: !detectMob() },
    { key: "nomor_kk", name: "Nomor KK", editable: true, width: 150, frozen: !detectMob() },
    { key: "nik", name: "NIK", editable: true, width: 150, frozen: !detectMob() },
    { key: "nama", name: "Nama", editable: true, width: 150, frozen: !detectMob() },
    { key: "jenis_kelamin", name: "L/P", editor: GenderTypeEditor, width: 150, frozen: !detectMob() },
    { key: "status_dalam_keluarga", name: "Kedudukan dalam Keluarga", editable: true, editor: familyTypeEditor, width: 250 },
    { key: "tempat_lahir", name: "Tempat Lahir", editable: true, width: 200 },
    { key: "tanggal_lahir", name: "Tanggal Lahir", editor: DateEditorNew, width: 160 },
    { key: "status_nikah", name: "Status Nikah", editable: true, editor: MarriedStatusTypeEditor, width: 150 },
    { key: "agama", name: "Agama", editable: true, editor: ReligionTypeEditor, width: 150 },
    { key: "gol_darah", name: "Golongan Darah", editor: BloodTypeEditor, width: 150 },
    { key: "suku", name: "Suku", editable: true, width: 150 },
    { key: "pendidikan_terakhir", name: "Pendidikan Terakhir", editable: true, editor: EducationTypeEditor, width: 200 },
    { key: "pekerjaan", name: "Pekerjaan", editable: true, width: 150 },
    { key: "penghasilan_perbulan", name: "Penghasilan/Bulan", editable: true, width: 150 },

    { key: "no_akta_kelahiran", name: "Nomor Akta Kelahiran", editable: true, width: 200 },
    { key: "akseptor_kb", name: "Jenis KB", editable: true, editor: KBStatusTypeEditor, width: 150 },
    { key: "disabilitas", name: "Jenis Disabilitas", editable: true, editor: DisabilitasStatusTypeEditor, width: 150 },

    { key: "status_rumah", name: "Status Rumah", editable: true, editor: rumahStatusTypeEditor, width: 150 },
    { key: "bukti_kepemilikan_rumah", name: "Bukti Kepemilikan Rumah", editable: true, editor: buktiRumahStatusTypeEditor, width: 200 },
    { key: "status_pbb", name: "Status PBB", editable: true, editor: pbbStatusTypeEditor, width: 150 },
    { key: "jenis_rumah", name: "Jenis Bangunan Rumah", editable: true, editor: rumahTypeEditor, width: 200 },
    
    { key: "sumber_air_minum", name: "Sumber Air Minum", editable: true, editor: sumberAirTypeEditor, width: 150 },
    { key: "sumber_air_masak", name: "Sumber Air Masak", editable: true, editor: sumberAirTypeEditor, width: 150 },
    { key: "sumber_air_mck", name: "Sumber Air MCK", editable: true, editor: sumberAirTypeEditor, width: 150 },
    { key: "sumber_penerangan", name: "Sumber Penerangan", editable: true, editor: peneranganTypeEditor, width: 150 },
    
    { key: "fasilitas_mck", name: "Fasilitas MCK", editable: true, editor: fasilitasTypeEditor, width: 150 },
    { key: "fasilitas_septic_tank", name: "Septic Tank", editable: true, editor: septicTankTypeEditor, width: 150 },

    { key: "kepemilikan_aset", name: "Kepemilikan Aset", editable: true, width: 200 },
    { key: "penerima_bantuan", name: "Penerima Bantuan (PKH/KIS/KIP dll)", editable: true, width: 200 },
    { key: "keterangan_lainnya", name: "Keterangan Lainnya", editable: true, width: 200 },




];

const validationSchema = Yup.object({
    urut_kk: Yup.number().required().typeError("Urut KK harus berisi angka"),
    nomor_kk: Yup.number().required().typeError("Nomor KK harus berisi angka"),
    nik: Yup.number().required().typeError("NIK harus berisi angka"),
    nama: Yup.string().required().typeError("Nama harus terisi"),
    jenis_kelamin: Yup.string().required().typeError("Jenis kelamin harus terisi"),
    status_dalam_keluarga: Yup.string().required().typeError("Status dalam keluarga harus terisi"),
    tempat_lahir: Yup.string().required().typeError("Tempat lahir harus terisi"),
    tanggal_lahir: Yup.string().required().typeError("Tanggal lahir harus terisi"),
    status_nikah: Yup.string().required().typeError("Status nikah harus terisi"),
    agama: Yup.string().required().typeError("Agama harus terisi"),
    gol_darah: Yup.string().required().typeError("Golongan darah harus terisi"),
    suku: Yup.string().required().typeError("Suku harus terisi"),
    pendidikan_terakhir: Yup.string().required().typeError("Pendidikan terakhir harus terisi"),
    pekerjaan: Yup.string().required().typeError("Pekerjaan harus terisi"),
    penghasilan_perbulan: Yup.string().required().typeError("Penghasilan perbulan harus terisi"),
    
    no_akta_kelahiran: Yup.string().required("No akta Kelahiran harus terisi").typeError("No akta Kelahiran harus terisi"),
    akseptor_kb: Yup.string().required("Jenis KB harus terisi").typeError("Jenis KB harus terisi"),
    disabilitas: Yup.string().required("Jenis disabilitas harus terisi").typeError("Jenis disabilitas harus terisi"),
    
    status_rumah: Yup.string().required("Status rumah harus terisi").typeError("Status rumah harus terisi"),
    bukti_kepemilikan_rumah: Yup.string().required("Bukti kepemilikan rumah harus terisi").typeError("Bukti kepemilikan rumah harus terisi"),
    status_pbb: Yup.string().required("Status PBB harus terisi").typeError("Status PBB Kelahiran harus terisi"),
    jenis_rumah: Yup.string().required("Jenis bangunan rumah  harus terisi").typeError("Jenis bangunan rumah  harus terisi"),

    sumber_air_minum: Yup.string().required("Sumber air minum harus terisi").typeError("Sumber air minum harus terisi"),
    sumber_air_masak: Yup.string().required("Sumber air masak harus terisi").typeError("Sumber air masak harus terisi"),
    sumber_air_mck: Yup.string().required("Sumber air MCK harus terisi").typeError("Sumber air MCK harus terisi"),
    sumber_penerangan: Yup.string().required("Sumber penerangan  harus terisi").typeError("Sumber penerangan harus terisi"),

    fasilitas_mck: Yup.string().required("Ketersediaan Fasilitas MCK harus terisi").typeError("Ketersediaan Fasilitas MCK harus terisi"),
    fasilitas_septic_tank: Yup.string().required("Ketersediaan fasilitas septic tank  harus terisi").typeError("Ketersediaan fasilitas septic tank  harus terisi"),


    // email: Yup.string().email().required(),
    // title: Yup.string().required(),
    // review: Yup.string().required(),
    // rating: Yup.number().min(1).max(10).required(),
    // date: Yup.date().default(() => new Date()),
    // wouldRecommend: Yup.boolean().default(false),
  });


export default class Example extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            rows: [
                { no: 1 },
            ],
            isLoading: false,
            isShowModal: false,
            modalText: "",
            isShowModalRT: true,
            modalRTText: "",
            isShowModalError: false,
            modalErrorText: "",
            kelurahan: [],
            rt: [],
            selectedTahun : "",
            selectedKelurahan : "",
            selectedRT : "",
            selectedRTText : "",
            isShowModalImport: false,
            importData: [],
            modalImportText: "",
        };
        this.addRow = this.addRow.bind(this);
        this.handleErrors = this.handleErrors.bind(this);
        this.fetchData = this.fetchData.bind(this);
        this.saveRow = this.saveRow.bind(this);
        this.saveImport = this.saveImport.bind(this);
        this.validate = this.validate.bind(this);
        this.updateRow = this.updateRow.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.closeModalError = this.closeModalError.bind(this);
        this.fetchRT = this.fetchRT.bind(this);
        this.closeModalRT = this.closeModalRT.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleImport = this.handleImport.bind(this);
        this.deleteRow = this.deleteRow.bind(this);

        this.tahunInput = React.createRef();
        this.kelurahanInput = React.createRef();
        this.RTInput = React.createRef();
        this.fileInput = React.createRef();
    }

    onGridRowsUpdated = ({ fromRow, toRow, updated }) => {
        this.setState(state => {
            const rows = state.rows.slice();
            for (let i = fromRow; i <= toRow; i++) {
                rows[i] = { ...rows[i], ...updated };
            }
            return { rows };
        });
    };

    addRow = () => {
        this.setState(state => {
            let rows = state.rows.slice();
            rows.push({ no: rows.length + 1 });
            return { rows };
        });

    }

    handleErrors = (response) => {
        if (!response.ok) {
            this.setState({ isLoading: false });
            this.setState({ isShowModal: true });
            this.setState({ modalText: "Error : " + response.statusText });
            throw Error(response.statusText);

        }
        return response;
    }

    fetchData = () => {
        console.log("Bearer " + getAuthData()?.jwt);
        this.setState({ isLoading: true });
        fetch(url_api + "/records/data_penduduk?filter=tahun,eq,"+this.state.selectedTahun+"&filter=sls_id,eq,"+this.state.selectedRT, {
            headers: {
                'Content-Type': 'application/json',
                'X-Authorization': "Bearer " + getAuthData()?.jwt
            },
        })
            .then(this.handleErrors)
            .then((response) => response.json())
            .then(data => {
                console.log(data.records);
                if (data.records.length > 0) {
                    // add number for rendering purpose
                    let newRow = data.records.slice();
                    for (let index = 0; index < newRow.length; index++) {
                        
                        newRow[index] = { ...newRow[index], ...{ no: index + 1 } };
                        if(newRow[index].tanggal_lahir){
                            let date = newRow[index].tanggal_lahir.split("-");
                            newRow[index] = { ...newRow[index], ...{ tanggal_lahir: date[2]+"-"+date[1]+"-"+date[0] } };
                        }

                    }
                    // this.setState({rows: data.records})
                    this.setState({ rows: newRow })
                }else{
                    let newRow = [
                        { no: 1 },
                    ];
                    this.setState({ rows: newRow })
                }
                this.setState({ isLoading: false });
            })
            .catch((error) => {
                console.log(error.message);
                this.setState({ isLoading: false });
                this.setState({ isShowModal: true });
                this.setState({ modalText: "Terjadi kesalahan jaringan, periksa kembali koneksi anda! " + error.message });
            });
    }

    isValidDate(dateString) {
        var regEx = /^\d{4}-\d{2}-\d{2}$/;
        if(!dateString.match(regEx)) return false;  // Invalid format
        var d = new Date(dateString);
        var dNum = d.getTime();
        if(!dNum && dNum !== 0) return false; // NaN value, Invalid date
        return d.toISOString().slice(0,10) === dateString;
    }

    saveRow = () => {
        // console.log(this.state.rows);
        let rows = this.state.rows.slice();
        for (let i = 0; i < rows.length; i++) {
            if (rows[i].penghasilan_perbulan) {
                let pendapatan = rows[i].penghasilan_perbulan.replace("Rp ", "");
                pendapatan = pendapatan.replaceAll(",", "");
                rows[i] = { ...rows[i], ...{ penghasilan_perbulan: pendapatan } };
            }
            if (rows[i].tanggal_lahir&&!this.isValidDate(rows[i].tanggal_lahir)) {
                rows[i] = { ...rows[i], ...{ tanggal_lahir: dayjs(rows[i].tanggal_lahir, "DD-MM-YYYY").format("YYYY-MM-DD") } };
            }
            delete rows[i].no;
            rows[i]["sls_id"] = this.state.selectedRT;
            rows[i]["tahun"] = this.state.selectedTahun;
        }
        console.log(rows);

        var newVar = rows.filter(row => row.id == null);
        var updatedVar = rows.filter(row => row.id != null);
        fetch(url_api + "/records/data_penduduk", {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
                'X-Authorization': "Bearer " + getAuthData()?.jwt
            },
            body: JSON.stringify(newVar),
        })
            .then(this.handleErrors)
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
                this.fetchData();
            })
            .catch((error) => {
                console.error('Error:', error);
                this.setState({ isShowModal: true });
                this.setState({ modalText: "Error : " + error });
            });
        if(updatedVar.length>0){
            this.updateRow(updatedVar);
        }
    }

    updateRow = (updatedVar) => {
        fetch(url_api + "/records/data_penduduk/"+Array.prototype.map.call(updatedVar, s => s.id).toString(), {
            method: 'PUT', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
                'X-Authorization': "Bearer " + getAuthData()?.jwt
            },
            body: JSON.stringify(updatedVar),
        })
            .then(this.handleErrors)
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
                this.fetchData();
            })
            .catch((error) => {
                console.error('Error:', error);
                this.setState({ isShowModal: true });
                this.setState({ modalText: "Error : " + error });
            });
    }

    fetchRT = () => {
        console.log("kode_wilayah " + getAuthData()?.kode_wilayah);
        this.setState({ isLoading: true });
        fetch(url_api + "/records/rt?filter=sls_id,sw," + getAuthData()?.kode_wilayah, {
            headers: {
                'Content-Type': 'application/json',
                'X-Authorization': "Bearer " + getAuthData()?.jwt
            },
        })
            .then(this.handleErrors)
            .then((response) => response.json())
            .then(data => {
                // if (data.records.length > 0) {
                //     // add number for rendering purpose
                //     let newRow = data.records.slice();
                //     for (let index = 0; index < newRow.length; index++) {
                //         newRow[index] = { ...newRow[index], ...{ no: index + 1 } };

                //     }
                //     this.setState({ rows: newRow })
                // }
                this.setState({ isLoading: false });
                console.log(data.records);

                // get unique desa/kelurahan
                const result = [];
                const map = new Map();
                for (const item of data.records) {
                    if(!map.has(item.desa_name)){
                        map.set(item.desa_name, true);    // set any value to Map
                        result.push({
                            value: item.desa_name,
                            desa_name: item.desa_name
                        });
                    }
                }

                console.log(result);
                this.setState({kelurahan: result, rt: data.records});


            })
            .catch((error) => {
                console.log(error.message);
                this.setState({ isLoading: false });
                this.setState({ isShowModal: true });
                this.setState({ modalText: "Terjadi kesalahan jaringan, periksa kembali koneksi anda! " + error.message });
            });
    }

    componentDidMount() {
        // this.fetchData();
        this.fetchRT();
    }

    closeModal() {
        this.setState({ isShowModal: false });
        this.setState({ modalText: "" });
    }

    closeModalError() {
        this.setState({ isShowModalError: false });
        this.setState({ modalErrorText: "" });
    }

    closeModalRT() {
        this.setState({ isShowModalRT: false });
        this.setState({ modalRTText: "" });
    }


    handleSubmit(event) {
        event.preventDefault();
        console.log("SUBMIT "+this.tahunInput.current.value);
        console.log("SUBMIT "+this.kelurahanInput.current.value);
        console.log("SUBMIT "+this.RTInput.current.value);
        if(this.tahunInput.current.value==0||this.kelurahanInput.current.value==0||this.RTInput.current.value==0){
            this.setState({modalRTText: "Isian tahun, kelurahan, RT tidak boleh kosong"});
            return;
            
        }
        console.log("Execute Submit");
        this.setState({modalRTText: ""});
        this.closeModalRT();
        this.setState({selectedTahun: this.tahunInput.current.value, selectedKelurahan: this.kelurahanInput.current.value, selectedRT: this.RTInput.current.value, selectedRTText: this.RTInput.current.options[this.RTInput.current.selectedIndex].text}, 
            ()=>{this.fetchData()});
        
    }

    deleteRow = (rowIdx) => {
        let rows = this.state.rows.slice();
        
        console.log("delete row "+rows[rowIdx]);
        fetch(url_api + "/records/data_penduduk/"+rows[rowIdx].id, {
            method: 'DELETE', 
            headers: {
                'Content-Type': 'application/json',
                'X-Authorization': "Bearer " + getAuthData()?.jwt
            },
        })
            .then(this.handleErrors)
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
                this.fetchData();
            })
            .catch((error) => {
                console.error('Error:', error);
                this.setState({ isShowModal: true });
                this.setState({ modalText: "Error : " + error });
            });
        
        if(!rows[rowIdx].id){
            const nextRows = [...rows];
            nextRows.splice(rowIdx, 1);
            // return nextRows;
            this.setState({rows: nextRows});

        }
    };

    validate = () =>{

        let errorText = "";
        for (let index = 0; index < this.state.rows.length; index++) {
            const element = this.state.rows[index];
            // validationSchema.validate(element, {abortEarly: false}).catch(function (err) {
            //     // err.name; // => 'ValidationError'
            //     // err.errors; // => ['Deve ser maior que 18']
            //     console.log("Index : "+index);
            //     console.log(err);
            //     errorText = errorText+"Index : "+index+"\n"+err;
            // });

            // validationSchema.validate(element, {abortEarly: false}).catch(function (err) {
            //     console.log("Index : "+index);
            //     err.inner.forEach(e => {
            //         console.log(e.message, e.path);
            //     });
            // });
            let row_number = index+1;

            try{
                validationSchema.validateSync(element, {abortEarly: false})

            }catch(err){
                errorText = errorText+"Baris : "+row_number+"\n";
                err.inner.forEach(e => {
                    // console.log(e);
                    errorText = errorText+" -"+e.message+"\n";
                });
                errorText = errorText+"\n";

            }
        }

        if(errorText!=""){
        // if(true){
            console.log("validate")
            this.setState({modalErrorText: errorText, isShowModalError: true});
        }

    }

    saveImport = (data) => {
        // console.log(this.state.rows);
        let rows = data;
        for (let i = 0; i < rows.length; i++) {
            if (rows[i].penghasilan_perbulan) {
                let pendapatan = rows[i].penghasilan_perbulan.replace("Rp ", "");
                pendapatan = pendapatan.replaceAll(",", "");
                rows[i] = { ...rows[i], ...{ penghasilan_perbulan: pendapatan } };
            }
            if (rows[i].tanggal_lahir&&!this.isValidDate(rows[i].tanggal_lahir)) {
                rows[i] = { ...rows[i], ...{ tanggal_lahir: dayjs(rows[i].tanggal_lahir, "DD-MM-YYYY").format("YYYY-MM-DD") } };
            }
            if(rows[i].tanggal_lahir==""){
                delete rows[i].tanggal_lahir;
            }
            if(rows[i].penghasilan_perbulan==""){
                delete rows[i].penghasilan_perbulan;
            }


            delete rows[i].no;
            rows[i]["sls_id"] = this.state.selectedRT;
            rows[i]["tahun"] = this.state.selectedTahun;
        }
        console.log(rows);

        var newVar = rows.filter(row => row.id == null);
        var updatedVar = rows.filter(row => row.id != null);
        fetch(url_api + "/records/data_penduduk", {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
                'X-Authorization': "Bearer " + getAuthData()?.jwt
            },
            body: JSON.stringify(newVar),
        })
            .then(this.handleErrors)
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
                this.fetchData();
            })
            .catch((error) => {
                console.error('Error:', error);
                this.setState({ isShowModal: true });
                this.setState({ modalText: "Error : " + error });
            });
        if(updatedVar.length>0){
            this.updateRow(updatedVar);
        }
    }

    handleImport(event) {
        event.preventDefault();
        console.log("SUBMIT "+this.fileInput.current.value);
        if(this.fileInput.current.value==0){
            this.setState({modalImportText: "Isian file tidak boleh kosong"});
            return;
            
        }
        console.log("Execute Submit");
        this.setState({modalImportText: ""});
        // console.log(this.fileInput.current.files)
        excel2json(this.fileInput.current.files, (data) => {
            try {
                var firstKey = Object.keys(data)[0];
                console.log('json', data[firstKey]);
                this.setState({importData: data[firstKey]});
                
                
                var importedKeys = Object.keys(data[firstKey][0]);
                var requiredKey = [];
                for (let index = 0; index < columns.length; index++) {
                    const element = columns[index];
                    if(element.key!="no"){
                        requiredKey.push(element.key);
                    }
                }

                console.log("importedKeys", importedKeys);
                console.log("requiredKey", requiredKey);

                if(requiredKey.every(i => importedKeys.includes(i))){
                    console.log("validasi benar");
                    this.setState({modalImportText: ""});
                    let newRow = this.state.rows.slice();
                    let deletedIndex = newRow.map(x => x.id);
                    console.log(deletedIndex);
                    if(deletedIndex?.length>0&&deletedIndex[0]){
                        //data awal terisi, delete yg lama terus import
                        deletedIndex = deletedIndex.join(",");
                        console.log("deletedIndex", deletedIndex);

                        fetch(url_api + "/records/data_penduduk/"+deletedIndex, {
                            method: 'DELETE', 
                            headers: {
                                'Content-Type': 'application/json',
                                'X-Authorization': "Bearer " + getAuthData()?.jwt
                            },
                        })
                            .then(this.handleErrors)
                            .then(response => response.json())
                            .then(res => {
                                console.log('Success:', res);
                                // this.fetchData();
                                this.saveImport(data[firstKey]);
                            })
                            .catch((error) => {
                                console.error('Error:', error);
                                this.setState({ isShowModal: true });
                                this.setState({ modalText: "Error : " + error });
                            });

                    }else{
                        //data awal kosong, tinggal import
                        this.saveImport(data[firstKey]);
                    }
                    this.setState({isShowModalImport: false});
                }else{
                    console.log("validasi salah");
                    this.setState({modalImportText: "Format file excel tidak sesuai"});
                    return;

                }
            
            // console.log("validasi",validationSchema.isValidSync(data[firstKey]));
            
            } catch (error) {
                this.setState({isShowModal: true, modalText: "Terjadi kesalahan, cek kembali template format excel sudah sesuai dan isan sudah terinput!"});
            }


            

        })
        
        
        // this.closeModalRT();
        // this.setState({selectedTahun: this.tahunInput.current.value, selectedKelurahan: this.kelurahanInput.current.value, selectedRT: this.RTInput.current.value, selectedRTText: this.RTInput.current.options[this.RTInput.current.selectedIndex].text}, 
        //     ()=>{this.fetchData()});
        
    }



    render() {
        const years = []
        for (let index = 2018; index < new Date().getFullYear()+5; index ++) {
            years.push(<option key={index}>{index}</option>)
        }
        return (
            <div style={{ width: "90%", margin: "auto" }}>
                <div style={{ margin: "10px 0px", float: "left" }}>
                    {/* <input type="text">{this.state.selectedKelurahan+" "+this.state.selectedTahun}</input> */}
                    {/* <input type="text" class="form-control" value={this.state.selectedKelurahan+" / "+this.state.selectedRTText+" / "+this.state.selectedTahun}
                        style={{width: "300px"}} disabled/>  */}
                    <div style={{display: "flex", alignItems: "center"}}>
                        <input type="text" class="form-control" value={this.state.selectedKelurahan+" / "+this.state.selectedRTText+" / "+this.state.selectedTahun}
                            style={{width: "300px"}} disabled/>
                        <IconButton aria-label="first" onClick={()=>{this.setState({isShowModalRT: true})}}>
                        {/* <IconButton aria-label="first" onClick={()=>{window.location.reload()}}> */}
                            <RefreshIcon />
                        </IconButton>
                    </div>
                </div>
                <div style={{ margin: "10px 0px", float: "right" }}>
                    <div style={{display: "flex", alignItems: "center", height: "45px"}}>
                        <a className="btn btn-success btn-sm" href={url_download_template} download>Download template</a>
                        <button type="button" className="btn btn-primary btn-sm" style={{ margin: "0px 2px" }} onClick={()=>{this.setState({isShowModalImport: true})}} >Import file</button>
                        <button type="button" className="btn btn-dark btn-sm" style={{ margin: "0px 2px" }} onClick={this.addRow} >Add Row</button>
                        <button type="button" className="btn btn-dark btn-sm" style={{ margin: "0px 2px" }} onClick={this.saveRow} >Save</button>
                        <button type="button" className="btn btn-dark btn-sm" style={{ margin: "0px 0px 0px 2px" }} onClick={()=>{this.saveRow(); this.validate();}} >Save & Validasi</button>
                    </div>
                </div>
                <ReactDataGrid
                    columns={columns}
                    rowGetter={i => this.state.rows[i]}
                    // rowsCount={12}
                    rowsCount={this.state.rows.length}
                    onGridRowsUpdated={this.onGridRowsUpdated}
                    enableCellSelect={true}
                    minHeight="600px"
                    contextMenu={
                        <ExampleContextMenu
                          onRowDelete={(e, { rowIdx }) => this.deleteRow(rowIdx)}
                        />
                    }
                    RowsContainer={ContextMenuTrigger}
                />
                <div id="divLoading" className={this.state.isLoading ? "show" : ""}>
                    <div className="cssload-tetrominos">
                        <div className="cssload-tetromino cssload-box1"></div>
                        <div className="cssload-tetromino cssload-box2"></div>
                        <div className="cssload-tetromino cssload-box3"></div>
                        <div className="cssload-tetromino cssload-box4"></div>
                    </div>
                </div>

                <Modal show={this.state.isShowModal} onHide={this.closeModal}>
                    <Modal.Header closeButton>
                        <Modal.Title>Terjadi Kesalahan!</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>{this.state.modalText}</Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={this.closeModal}>
                            Close
                        </Button>
                    </Modal.Footer>
                </Modal>

                {/* RT */}
                <Modal show={this.state.isShowModalRT} onHide={()=>{}}>
                    <form onSubmit={this.handleSubmit}>

                    <Modal.Header>
                        <Modal.Title>Pilih RT yang akan di Input</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <select className="form-select" aria-label="Default select example" style={{ margin: "10px 0px" }} ref={this.tahunInput}>
                            <option value="0" selected>Pilih Tahun</option>
                            {years}
                        </select>
                        <select className="form-select" aria-label="Default select example" style={{ margin: "10px 0px" }} ref={this.kelurahanInput}>
                            <option value="0" selected>Pilih Kelurahan</option>
                            {this.state.kelurahan.map(function(object, i){
                                return <option value={object.value} key={i}>{object.value}</option>;
                            })}
                            {/* <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option> */}
                        </select>
                        <select className="form-select" aria-label="Default select example" style={{ margin: "10px 0px" }} ref={this.RTInput}>
                            <option value="0" selected>Pilih RT/RW</option>
                            {this.state.rt.map(function(object, i){
                                return <option value={object.sls_id} key={i}>{object.sls_name}</option>;
                            })}
                            {/* <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option> */}
                        </select>
                        <p style={{margin: "auto", color: "red"}}>{this.state.modalRTText}</p>

                    </Modal.Body>
                    <Modal.Footer>
                        <Button type="submit" variant="primary">
                            Submit
                        </Button>
                    </Modal.Footer>
                    </form>
                </Modal>

                {/* Modal Error */}
                <Modal show={this.state.isShowModalError} onHide={this.closeModalError}>
                    <Modal.Header closeButton>
                        <Modal.Title>Daftar Error</Modal.Title>
                    </Modal.Header>
                    <Modal.Body><pre>{this.state.modalErrorText}</pre></Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={this.closeModalError}>
                            Close
                        </Button>
                    </Modal.Footer>
                </Modal>

                {/* Modal Import */}
                <Modal show={this.state.isShowModalImport} onHide={()=>{this.setState({isShowModalImport: false})}}>
                    <form onSubmit={this.handleImport}>
                    <Modal.Header closeButton>
                        <Modal.Title>Import file excel</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div class="alert alert-warning" role="alert">
                            Tombol Import akan menimpa data entrian lama dengan data dari excel! 
                        </div>
                        <input ref={this.fileInput} type="file" multiple="false" id="sheets" accept="application/x-iwork-keynote-sffnumbers,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={null} />
                        <p style={{margin: "auto", color: "red"}}>{this.state.modalImportText}</p>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={()=>{this.setState({isShowModalImport: false})}}>
                            Cancel
                        </Button>
                        <Button type="submit" variant="primary">
                            Import
                        </Button>
                    </Modal.Footer>
                    </form>
                </Modal>
                

            </div>

        );
    }
}


function ExampleContextMenu({
    idx,
    id,
    rowIdx,
    onRowDelete,
  }) {
    return (
      <ContextMenu id={id}>
        <MenuItem data={{ rowIdx, idx }} onClick={onRowDelete}>
          Delete Row
        </MenuItem>
      </ContextMenu>
    );
  }