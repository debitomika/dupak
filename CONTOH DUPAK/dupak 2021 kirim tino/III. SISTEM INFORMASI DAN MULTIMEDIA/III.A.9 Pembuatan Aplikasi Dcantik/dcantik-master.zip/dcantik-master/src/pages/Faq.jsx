import React from 'react'

export default function Faq() {
    return (
        <div>
            <div style={{margin: "50px auto", textAlign: "left", width: "80%"}}>
                <h3>FAQ</h3>
                <hr/>
                <strong>A : Apa itu Kelurahan Cantik Kendari?</strong>
                <p>Q : Kelurahan cantik merupakan kerjasama antara BPS dengan Kelurahan di Kota Kendari dalam rangka pembinaan terkait data statistik baik dari segi pengumpulan, pengolahan, hingga diseminasi data
                    di kelurahan.
                </p>

                <br/>
                <strong>A : Kelurahan apa saja yang tergabung dalam Kelurahan Cantik?</strong>
                <p>Q : Untuk tahap awal kelurahan yang tergabung dalam Kelurahan Cantik adalah Kelurahan Korumba, Kecamatan Mandonga diharapkan kedepannya Kelurahan Cantik juga dapat diimplementasikan di Kelurahan lain di Kendari.
                </p>

                <br/>
                <strong>A : Apa saja fitur website Kelurahan Cantik?</strong>
                <p>Q : Website kelurahan cantik merupakan wadah tempat melakukan input data statistik yang dikumpulkan oleh petugas Kelurahan Korumba terkait kondisi warga di kelurahannya.
                    Fitur dari website ini antara lain : input data warga menurut RT dan tahun, validasi kewajaran isian data. Menu report untuk melihat ringkasan data yg telah di input dan menu download data untuk mengambil file excel yang telah diinput sebelumnya.
                </p>

                <br/>
                <strong>A : Siapa saja yang bisa melakukan input data di Kelurahan Cantik?</strong>
                <p>Q : Petugas kelurahan dan RT/RW di kelurahan Korumba masing-masing akan diberikan akun untuk dapat melakukan input data di Kelurahan Cantik.
                </p>

                <br/>
                <strong>A : Cara melaporkan jika terdapat bug/gangguan pada website desa cantik?</strong>
                <p>Q : Bisa melaporkan ke pembuat website desa cantik melalui email di wayan.saputra@bps.go.id atau via telp/WA 082292196832.
                </p>

                <br/>
                <strong>A : Panduan penggunaan aplikasi dcantik?</strong>
                <p>Q : Panduan dapat diunduh di <a href="https://s.bps.go.id/7471-panduan-dcantik">link berikut</a> 
                </p>

            </div>
        </div>
    )
}
