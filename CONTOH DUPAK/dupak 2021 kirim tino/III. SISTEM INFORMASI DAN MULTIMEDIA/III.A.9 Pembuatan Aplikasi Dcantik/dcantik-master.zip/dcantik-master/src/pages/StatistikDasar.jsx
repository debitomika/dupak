import React from 'react'

export default function StatistikDasar() {
    return (
        <div>
            <h1>This is Statistik Dasar</h1>
        </div>
    )
}
