import React, {useRef, useState} from 'react'
import { url_login } from "../constant/constant";
import { useHistory, useLocation } from 'react-router-dom';

export default function Login() {
    let history = useHistory();
    let location = useLocation();
    let { from } = location.state || { from: { pathname: "/" } };
    const usernameEl = useRef(null);
    const passwordEl = useRef(null);
    const [isError, setIsError] = useState(false);

    const handleSubmit = (event) => {
        console.log(usernameEl.current.value);
        console.log(passwordEl.current.value);

        let postData = {
            username : usernameEl.current.value,
            password : passwordEl.current.value
        }

        fetch(url_login, {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(postData),
        })
            .then(response => response.json())
            .then(data =>{
                console.log(data);
                if(data.message=="Successful login."){
                    // console.log(data);
                    let dcantik_state = data;
                    dcantik_state["date"] = new Date();
                    localStorage.setItem("dcantik_state", JSON.stringify(dcantik_state));
                    // history.push('/');
                    history.replace(from);
                }else{
                    // console.log("incorrect username or password");
                    setIsError(true);
                }

            })
            .catch((error) => {
                console.error('Error:', error);
            });

        event.preventDefault();
    }

    return (
        <div style={{width: "100%", height: "100%", backgroundColor: "#f2f2f2"}}>
            <div class="content">
                <h1>Login</h1>
                <form style={{margin: "50px 0px"}} onSubmit={handleSubmit}>
                    <input type="text" class="form-control" placeholder="Username" style={{margin: "20px 0px"}} ref={usernameEl}></input>
                    <input type="password" class="form-control" placeholder="Password" style={{margin: "20px 0px"}} ref={passwordEl}></input>
                    <p style={{color: "red", display: isError? "block":"none"}}>Incorrect username or password!</p>
                    <button type="submit" class="btn btn-dark" style={{width: "100%", borderRadius: "10px"}}>Sign In</button>
                </form>
            </div>
        </div>
    )
}
