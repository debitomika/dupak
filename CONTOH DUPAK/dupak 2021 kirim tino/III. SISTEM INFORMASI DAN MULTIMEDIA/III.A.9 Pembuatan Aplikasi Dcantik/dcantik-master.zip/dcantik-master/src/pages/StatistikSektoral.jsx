import React, { Component } from 'react'
import { useTable, usePagination, useSortBy } from "react-table";
import Button from '@material-ui/core/Button';
import GetAppIcon from '@material-ui/icons/GetApp';
import IconButton from '@material-ui/core/IconButton';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import LastPageIcon from '@material-ui/icons/LastPage';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import NavigateBeforeIcon from '@material-ui/icons/NavigateBefore';
import { url_rekapitulasi, url_rekapitulasi_chart, getAuthData } from "../constant/constant";
import Modal from 'react-bootstrap/Modal';
import { Bar } from "react-chartjs-2";

const columns = [
    {
        Header: "Provinsi",
        accessor: "prov_name"
    },
    {
        Header: "Kabupaten",
        accessor: "kab_name"
    },
    {
        Header: "Kecamatan",
        accessor: "kec_name"
    },
    {
        Header: "Kelurahan",
        accessor: "desa_name"
    },
    {
        Header: "SLS",
        accessor: "sls_name"
    },
    {
        Header: "Jumlah Baris Entrian",
        accessor: "jumlah"
    },
];

// const dataTable = [{"id_satker":"7400","title":"Sosialisasi Dukcapil","jumlah_tamu":"50","tanggal":"2020-02-12"},
// {"id_satker":"7400","title":"Sosialisasi Diknas","jumlah_tamu":"20","tanggal":"2020-02-20"},
// {"id_satker":"7400","title":"Sosialisasi Diknas","jumlah_tamu":"20","tanggal":"2020-02-20"},
// ];

let dataBar = {
    labels: [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July"
    ],
    datasets: [
        {
            label: "Laki-laki",
            backgroundColor: "rgba(255,99,132,0.2)",
            borderColor: "rgba(255,99,132,1)",
            borderWidth: 1,
            //stack: 1,
            hoverBackgroundColor: "rgba(255,99,132,0.4)",
            hoverBorderColor: "rgba(255,99,132,1)",
            data: [65, 59, 80, 81, 56, 55, 40]
        },

        {
            label: "Perempuan",
            backgroundColor: "rgba(155,231,91,0.2)",
            borderColor: "rgba(255,99,132,1)",
            borderWidth: 1,
            //stack: 1,
            hoverBackgroundColor: "rgba(155,231,91,0.4)",
            hoverBorderColor: "rgba(255,99,132,1)",
            data: [45, 79, 50, 41, 16, 85, 20]
        },

        {
            label: "Jenis Kelamin Belum diinput",
            backgroundColor: "rgba(255,193,7,0.2)",
            borderColor: "rgba(255,99,132,1)",
            borderWidth: 1,
            //stack: 1,
            hoverBackgroundColor: "rgba(255,193,7,0.4)",
            hoverBorderColor: "rgba(255,99,132,1)",
            data: [45, 79, 50, 41, 16, 85, 20]
        }
    ]
}

// const options = {
//     responsive: true,
//     legend: {
//         display: false,
//     },
//     type: "bar"
//     //   scales: {
//     //     xAxes: [{
//     //         stacked: true
//     //     }],
//     //     yAxes: [{
//     //         stacked: true
//     //     }]
//     // }
// };

// const options = {
//     type: 'bar',
//     data: dataBar,
//     options: {
//       indexAxis: 'y',
//       // Elements options apply to all of the options unless overridden in a dataset
//       // In this case, we are setting the border of each horizontal bar to be 2px wide
//       elements: {
//         bar: {
//           borderWidth: 2,
//         }
//       },
//       responsive: true,
//       plugins: {
//         legend: {
//           position: 'right',
//         },
//         title: {
//           display: true,
//           text: 'Chart.js Horizontal Bar Chart'
//         }
//       }
//     },
//   };

// const dataBar = {
//     labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
//     datasets: [
//       {
//         label: 'Laki-laki',
//         data: [1, 2, 3, 4, 5, 6],
//         backgroundColor: [
//           'rgba(255, 99, 132, 0.2)',
//           'rgba(54, 162, 235, 0.2)',
//           'rgba(255, 206, 86, 0.2)',
//           'rgba(75, 192, 192, 0.2)',
//           'rgba(153, 102, 255, 0.2)',
//           'rgba(255, 159, 64, 0.2)',
//         ],
//         borderColor: [
//           'rgba(255, 99, 132, 1)',
//           'rgba(54, 162, 235, 1)',
//           'rgba(255, 206, 86, 1)',
//           'rgba(75, 192, 192, 1)',
//           'rgba(153, 102, 255, 1)',
//           'rgba(255, 159, 64, 1)',
//         ],
//         borderWidth: 1,
//       },
//       {
//         label: 'Perempuan',
//         data: [12, 19, 3, 5, 2, 3],
//         backgroundColor: [
//           'rgba(255, 99, 132, 0.2)',
//           'rgba(54, 162, 235, 0.2)',
//           'rgba(255, 206, 86, 0.2)',
//           'rgba(75, 192, 192, 0.2)',
//           'rgba(153, 102, 255, 0.2)',
//           'rgba(255, 159, 64, 0.2)',
//         ],
//         borderColor: [
//           'rgba(255, 99, 132, 1)',
//           'rgba(54, 162, 235, 1)',
//           'rgba(255, 206, 86, 1)',
//           'rgba(75, 192, 192, 1)',
//           'rgba(153, 102, 255, 1)',
//           'rgba(255, 159, 64, 1)',
//         ],
//         borderWidth: 1,
//       },
//     ],
//   };
  
  const options = {
    indexAxis: 'y',
    // Elements options apply to all of the options unless overridden in a dataset
    // In this case, we are setting the border of each horizontal bar to be 2px wide
    elements: {
      bar: {
        borderWidth: 2,
      },
    },
    responsive: true,
    plugins: {
      legend: {
        position: 'right',
      },
      title: {
        display: false,
        text: 'Chart.js Horizontal Bar Chart',
      },
    },
  };


export default class StatistikSektoral extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dataTable: [],
            isLoading: false,
            isShowModal: false,
            modalText: "",
            selectedYear: new Date().getFullYear(),
            dataChart: [],
            dataChartOri: [],
            chartHeight : 500
        };
        this.fetchRekapitulasi = this.fetchRekapitulasi.bind(this);
        this.fetchRekapitulasiChart = this.fetchRekapitulasiChart.bind(this);
        this.handleErrors = this.handleErrors.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.onYearChange = this.onYearChange.bind(this);

        this.tahunInput = React.createRef();
    }

    handleErrors = (response) => {
        if (!response.ok) {
            this.setState({ isLoading: false });
            this.setState({ isShowModal: true });
            this.setState({ modalText: "Error : " + response.statusText });
            throw Error(response.statusText);

        }
        return response;
    }

    closeModal() {
        this.setState({ isShowModal: false });
        this.setState({ modalText: "" });
    }

    fetchRekapitulasi = (tahun) => {
        this.setState({ isLoading: true });
        fetch(url_rekapitulasi, {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
                // 'X-Authorization': "Bearer " + getAuthData()?.jwt
            },
            body: JSON.stringify({ tahun: tahun }),
        })
            .then(this.handleErrors)
            .then(response => response.json())
            .then(data => {
                this.setState({ isLoading: false });
                console.log('Success:', data);
                this.setState({ dataTable: data });
            })
            .catch((error) => {
                this.setState({ isLoading: false });
                console.error('Error:', error);
                this.setState({ isShowModal: true });
                this.setState({ modalText: "Error : " + error });
            });
    }

    fetchRekapitulasiChart = (tahun, sls_id) => {
        this.setState({ isLoading: true });
        console.log("fetch chart")
        fetch(url_rekapitulasi_chart, {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
                // 'X-Authorization': "Bearer " + getAuthData()?.jwt
            },
            body: JSON.stringify({ tahun: tahun, sls_id: sls_id }),
        })
            .then(this.handleErrors)
            .then(response => response.json())
            .then(data => {
                this.setState({ isLoading: false });
                console.log('Success chart:', data);
                

                // get unique RT
                const result = [];
                const map = new Map();
                for (const item of data) {
                    if(!map.has(item.sls_name)){
                        map.set(item.sls_name, true);    // set any value to Map
                        result.push(item.sls_name);
                    }
                }

                // get laki-laki
                let result_laki = [];
                let result_perempuan = [];
                let result_null = [];
                for (let index = 0; index < data.length; index++) {
                    const element = data[index];
                    if(element.tahun){
                        result_laki.push(element.jumlah_laki);
                        result_perempuan.push(element.jumlah_perempuan);
                        result_null.push(element.jumlah_null);

                    }else{
                        result_laki.push("0");
                        result_perempuan.push("0");
                        result_null.push("0");
                    }
                    
                }

                console.log("result_laki", result_laki);

                let dataBarNew = JSON.parse(JSON.stringify(dataBar));
                dataBarNew.datasets[0].data = result_laki;
                dataBarNew.labels = result;
                dataBarNew.datasets[1].data = result_perempuan;
                dataBarNew.datasets[2].data = result_null;

                this.setState({ dataChart: dataBarNew, dataChartOri: data});
            })
            .catch((error) => {
                this.setState({ isLoading: false });
                console.error('Error:', error);
                this.setState({ isShowModal: true });
                this.setState({ modalText: "Error : " + error });
            });
    }

    componentDidMount() {
        // this.fetchData();
        console.log(getAuthData()?.kode_wilayah);
        this.fetchRekapitulasi(this.state.selectedYear);
        this.fetchRekapitulasiChart(this.state.selectedYear, getAuthData()?.kode_wilayah);
    }

    onYearChange() {
        this.setState({ selectedYear: this.tahunInput.current.value }, () => {
            this.fetchRekapitulasi(this.state.selectedYear);
            this.fetchRekapitulasiChart(this.state.selectedYear, getAuthData()?.kode_wilayah);
        });

    }



    render() {
        const years = []
        for (let index = 2018; index < new Date().getFullYear() + 5; index++) {
            years.push(<option key={index}>{index}</option>)
        }
        return (
            <div>
                <div style={{ margin: "50px auto", textAlign: "left", width: "80%" }}>
                    <h3 style={{ display: "contents", maxWidth: "300px" }}>Report Jumlah Entrian</h3>
                    <select onChange={this.onYearChange} defaultValue={this.state.selectedYear} className="form-select" aria-label="Default select example" style={{ margin: "10px 0px", float: "right", width: "200px" }} ref={this.tahunInput}>
                        {/* <option value="0">Pilih Tahun</option> */}
                        {years}
                    </select>
                    {/* <hr/> */}
                    <Table columns={columns} data={this.state.dataTable} url_download={""} />
                    <br/>
                    <br/>
                    <h4 style={{margin: "50px 0px"}}>Jumlah Laki-Laki & Perempuan berdasarkan RT/RW Kelurahan {this.state.dataChartOri[0]?.kec_name} </h4>
                    <Bar
                        data={this.state.dataChart}
                        width={null}
                        height={this.state.chartHeight}
                        options={options}
                    />


                    <div id="divLoading" className={this.state.isLoading ? "show" : ""}>
                        <div className="cssload-tetrominos">
                            <div className="cssload-tetromino cssload-box1"></div>
                            <div className="cssload-tetromino cssload-box2"></div>
                            <div className="cssload-tetromino cssload-box3"></div>
                            <div className="cssload-tetromino cssload-box4"></div>
                        </div>
                    </div>
                    <Modal show={this.state.isShowModal} onHide={this.closeModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>Terjadi Kesalahan!</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>{this.state.modalText}</Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.closeModal}>
                                Close
                        </Button>
                        </Modal.Footer>
                    </Modal>

                </div>
            </div>
        )
    }
}


function Table({ columns, data, url_download }) {
    // Use the state and functions returned from useTable to build your UI
    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        prepareRow,
        page, // Instead of using 'rows', we'll use page,
        // which has only the rows for the active page

        // The rest of these things are super handy, too ;)
        canPreviousPage,
        canNextPage,
        pageOptions,
        pageCount,
        gotoPage,
        nextPage,
        previousPage,
        setPageSize,
        state: { pageIndex, pageSize },
    } = useTable(
        {
            columns,
            data,
            initialState: { pageIndex: 0 },
        },
        useSortBy,
        usePagination
    )

    // Render the UI for your table
    return (
        <>
            <table className="table table-bordered" {...getTableProps()}>
                <thead>
                    {headerGroups.map(headerGroup => (
                        <tr {...headerGroup.getHeaderGroupProps()}>
                            {headerGroup.headers.map(column => (
                                // Add the sorting props to control sorting. For this example
                                // we can add them into the header props
                                <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                                    {column.render('Header')}
                                    {/* Add a sort direction indicator */}
                                    <span>
                                        {column.isSorted
                                            ? column.isSortedDesc
                                                ? ' ⏷'
                                                : ' ⏶'
                                            : ''}
                                    </span>
                                </th>
                            ))}
                        </tr>
                    ))}
                </thead>
                <tbody {...getTableBodyProps()}>
                    {page.map((row, i) => {
                        prepareRow(row)
                        return (
                            <tr {...row.getRowProps()}>
                                {row.cells.map(cell => {
                                    return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                                })}
                            </tr>
                        )
                    })}
                </tbody>
            </table>

            {/* <Button onClick={()=>{window.open(url_download, '_blank');}} variant="contained" color="primary" style={{textTransform: "none"}}>
                <GetAppIcon/> Download
            </Button> */}

            <div style={{ float: "right" }}>
                <IconButton aria-label="first" onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
                    {/* <FirstPageIcon style={{ color: "#5f6367", fontSize: 24 }} /> */}
                    <FirstPageIcon />
                </IconButton>
                <IconButton aria-label="back" onClick={() => previousPage()} disabled={!canPreviousPage}>
                    {/* <ArrowBackIosIcon style={{ color: "#5f6367", fontSize: 14 }} /> */}
                    <NavigateBeforeIcon />
                </IconButton>
                <IconButton aria-label="next" onClick={() => nextPage()} disabled={!canNextPage}>
                    {/* <ArrowForwardIosIcon style={{ color: "#5f6367", fontSize: 14 }} /> */}
                    <NavigateNextIcon />
                </IconButton>
                <IconButton aria-label="last" onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
                    {/* <LastPageIcon style={{ color: "#5f6367", fontSize: 24 }} /> */}
                    <LastPageIcon />
                </IconButton>

                <span>
                    Page{' '}
                    <strong>
                        {pageIndex + 1} of {pageOptions.length}
                    </strong>{' '}
                </span>
                <span>
                    | Go to page:{' '}
                    <input
                        type="number"
                        defaultValue={pageIndex + 1}
                        onChange={e => {
                            const page = e.target.value ? Number(e.target.value) - 1 : 0
                            gotoPage(page)
                        }}
                        style={{ width: '100px', lineHeight: 1.5 }}
                    />
                </span>{' '}
                <select
                    style={{ height: "30px" }}
                    value={pageSize}
                    onChange={e => {
                        setPageSize(Number(e.target.value))
                    }}
                >
                    {[10, 20, 30, 40, 50].map(pageSize => (
                        <option key={pageSize} value={pageSize}>
                            Show {pageSize}
                        </option>
                    ))}
                </select>
            </div>
        </>
    )
}
