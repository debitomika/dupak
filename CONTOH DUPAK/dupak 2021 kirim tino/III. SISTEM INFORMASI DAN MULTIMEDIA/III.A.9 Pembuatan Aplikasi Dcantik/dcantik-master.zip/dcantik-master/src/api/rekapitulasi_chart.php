<?php

header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dcantik";

$_POST = json_decode(file_get_contents("php://input"),true);

$result = "";
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT a.*, b.tahun, SUM(CASE WHEN b.jenis_kelamin = 'Laki-laki' THEN 1 ELSE 0 END) AS jumlah_laki, SUM(CASE WHEN b.jenis_kelamin = 'Perempuan' THEN 1 ELSE 0 END) AS jumlah_perempuan, SUM(CASE WHEN b.jenis_kelamin IS NULL THEN 1 ELSE 0 END) AS jumlah_null, COUNT(b.id) AS jumlah 
    FROM rt a LEFT JOIN ( SELECT * FROM data_penduduk WHERE tahun = :tahun AND sls_id LIKE :sls_id ) b ON a.sls_id = b.sls_id GROUP BY a.sls_id 
    HAVING a.sls_id LIKE :sls_id ORDER BY `jumlah` DESC");
    // $stmt = $conn->prepare("SELECT * FROM `event`");
    $sls_id = "7471010012%";
    error_reporting(0);
    if($_POST["sls_id"]){
        $sls_id = $_POST["sls_id"]."%";
    }
            $stmt->bindParam(':tahun', $_POST["tahun"]);
            $stmt->bindParam(':sls_id', $sls_id);
    $stmt->execute();
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    $result = $stmt->fetchAll();
        
} catch (PDOException $e) {
    $result = $e->getMessage();
}

echo json_encode($result);


?>