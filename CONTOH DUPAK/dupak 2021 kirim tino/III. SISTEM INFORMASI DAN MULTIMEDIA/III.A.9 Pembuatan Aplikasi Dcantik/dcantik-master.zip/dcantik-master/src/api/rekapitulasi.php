<?php

header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dcantik";

$_POST = json_decode(file_get_contents("php://input"),true);

$result = "";
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT a.*, b.tahun, COUNT(b.id) AS jumlah FROM rt a LEFT JOIN ( SELECT * FROM data_penduduk WHERE tahun = :tahun ) b ON a.sls_id = b.sls_id GROUP BY a.sls_id /*HAVING b.tahun=2018 OR b.tahun IS NULL*/ ORDER BY `jumlah` DESC");
    // $stmt = $conn->prepare("SELECT * FROM `event`");
            $stmt->bindParam(':tahun', $_POST["tahun"]);
    $stmt->execute();
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    $result = $stmt->fetchAll();
        
} catch (PDOException $e) {
    $result = $e->getMessage();
}

echo json_encode($result);


?>