import React from "react";
import ReactDOM from "react-dom";
// import Cleave from 'cleave.js/react';
import Input from '@material-ui/core/Input';
import NumberFormat from "react-number-format";
// import TextField from "@material-ui/core/TextField";

// var cleave = new Cleave('.input-element', {
//   numeral: true,
//   numeralThousandsGroupStyle: 'thousand'
// });

function NumberFormatCustom(props) {
  const { inputRef, onChange, ...other } = props;
  console.log("props");
  console.log(props);

  return (
    <NumberFormat
      {...other}
      getInputRef={inputRef}
      onValueChange={values => {
        onChange({
          target: {
            // name: props.name,
            value: values.value
          }
        });
      }}
      thousandSeparator
      // prefix="$"
      // isNumericString
    />
  );
}


class CleaveEditor extends React.Component {
  constructor(props) {
    super(props);
    this.state = { color: this.props.value };
    this.onChange = this.onChange.bind(this);
  }

  getValue() {
    return { penghasilan_perbulan: this.state.color };
  }

  getInputNode() {
    return ReactDOM.findDOMNode(this).getElementsByTagName("input")[0];
  }

  onChange = event => {
    // return this.setState({ color: event.target.value }, () => this.props.onCommit());
    return this.setState({ color: event.target.value });
  };
  render() {
    return <Input
      // placeholder="0.00"
      value={this.state.color}
      // options={{
      //   prefix: "Rp ",
      //   numeral: true,
      //   numeralThousandsGroupStyle: "thousand",
      //   // prefix: "Rp. "
      // }}
      onChange={this.onChange}
      className="form-field"
      disableUnderline={true}
      variant="standard"
      inputComponent={NumberFormatCustom}
      // inputProps={{
      // }}
      name="numberformat"
      id="formatted-numberformat-input"
    />;
  }
}
export default CleaveEditor;
