import React from 'react'

export default function Attention() {
    return (
        <div className="indicator-1afSc8" data-tutorial-id="writing-messages">
            <div className="animationContainer-C1kDfz notAnimating-2EIRej highPriority-2lg-eA"><div>
                <div className="top-3fo3zT notAnimating-2EIRej" />
                <div className="bottom-UE1eOv notAnimating-2EIRej" />
            </div>
                <div className="innerCircle-2Tsscg notAnimating-2EIRej highPriority-2lg-eA" />
                <div className="outerCircle-2K0c82 notAnimating-2EIRej highPriority-2lg-eA" /></div>
        </div>
    )
}
