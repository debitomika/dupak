import React from "react";
import ReactDOM from "react-dom";
import {
  DateInput,
} from 'semantic-ui-calendar-react';


class DateEditorNew extends React.Component {
  constructor(props) {
    super(props);
    this.state = { color: this.props.value };
    this.onChange = this.onChange.bind(this);
  }

  getValue() {
    return { tanggal_lahir: this.state.color };
  }

  getInputNode() {
    return ReactDOM.findDOMNode(this).getElementsByTagName("input")[0];
  }

  onChange = event => {
    // return this.setState({ color: event.target.value }, () => this.props.onCommit());
    return this.setState({ color: event.target.value });
  };

  handleChange = (event, {name, value}) => {
    this.setState({ color: value });
    // if (this.state.hasOwnProperty(name)) {
    //   this.setState({ [name]: value });
    // }
  }

  render() {
    return <DateInput
          name="date"
          placeholder="Date"
          value={this.state.color}
          iconPosition="left"
          onChange={this.handleChange}
        />;
  }
}
export default DateEditorNew;
