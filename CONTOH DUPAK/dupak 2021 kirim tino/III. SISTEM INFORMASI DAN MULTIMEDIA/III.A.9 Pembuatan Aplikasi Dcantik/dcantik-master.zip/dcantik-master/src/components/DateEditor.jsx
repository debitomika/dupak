import React from "react";
import ReactDOM from "react-dom";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
import DatePicker from 'react-date-picker';
var dayjs = require('dayjs'); 

class ColorEditor extends React.Component {
  constructor(props) {
    super(props);
    console.log("this.props.value =>");
    console.log(this.props.value);
    if (this.props.value && this.props.value!="Invalid Date"){
      console.log("dayjs => ");
      console.log(this.props.value,);
      
      var parts = this.props.value.split('-');
      // Please pay attention to the month (parts[1]); JavaScript counts months from 0:
      // January - 0, February - 1, etc.
      var mydate = new Date(parts[2], parts[1] - 1, parts[0]); 
      this.state = { color: mydate };

    }else{
      this.state = { color: null };
    }
  }

  getValue() {
    return { tanggal_lahir: dayjs(this.state.color).format("DD-MM-YYYY") };
  }

  getInputNode() {
    return ReactDOM.findDOMNode(this).getElementsByTagName("input")[0];
  }

  onChange = date => {
    return this.setState({ color: date }, () => this.props.onCommit());
  };
  render() {
    return <DatePicker value={this.state.color} onChange={this.onChange} format="dd-MM-yyyy" />;
  }
}
export default ColorEditor;
