import React from 'react';
import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect
} from "react-router-dom";
import Home from './pages/Home';
import Saran from './pages/Saran';
import Navbar from './components/Navbar';
import Konsultasi from './pages/Konsultasi';
import Download from './pages/Download';
import StatistikSektoral from './pages/StatistikSektoral';
import StatistikDasar from './pages/StatistikDasar';
import Faq from './pages/Faq';
import Login from './pages/Login';
import Attention from './components/Attention';
import { isLogin } from './constant/constant';

function App() {
  return (
    <div className="App">
      <Router basename={process.env.PUBLIC_URL}>
          <Switch>
            <Route path="/login">
              <Login />
            </Route>
            <>
            <Navbar/>
            <PrivateRoute path="/input-data">
              <Konsultasi />
            </PrivateRoute>
            <PrivateRoute path="/download-data">
              <Download />
            </PrivateRoute>
            <Route path="/report">
              <StatistikSektoral />
            </Route>
            {/* <Route path="/statistik-dasar">
              <StatistikDasar />
            </Route>
            <Route path="/saran">
              <Saran />
            </Route> */}
            <Route path="/faq">
              <Faq />
            </Route>
            <Route exact path="/">
              <Home />
            </Route>
            <Attention/>
            </>
          </Switch>
      </Router>

    </div>
  );
}

export default App;

function PrivateRoute({ children, ...rest }) {
  return (
    <Route
      {...rest}
      render={({ location }) =>
        isLogin() ? (
          children
        ) : (
            <Redirect
              to={{
                pathname: "/login",
                state: { from: location }
              }}
            />
          )
      }
    />
  );
}