package com.virtualbox.torchick.rog.adapter;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class PubSingleton {
    private static  PubSingleton mInstance;
    private RequestQueue requestQueue;
    private static Context mContext;

    private PubSingleton(Context context){
        mContext = context;
        requestQueue = getRequestQueue();
    }

    private RequestQueue getRequestQueue(){
        if(requestQueue==null){
            requestQueue = Volley.newRequestQueue(mContext.getApplicationContext());

        }
        return requestQueue;
    }
    public static synchronized PubSingleton getmInstance(Context context){
        if(mInstance==null){
            mInstance = new PubSingleton(context);
        }
        return  mInstance ;
    }

    public<T> void addToRequestQueue(Request<T> request){
        getRequestQueue().add(request);
    }
}

