package com.virtualbox.torchick.rog.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import com.virtualbox.torchick.rog.R;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class AboutActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_main);
        setTitle("Tentang Aplikasi");
    }
}