package com.virtualbox.torchick.rog.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.activity.DetailBeritaActivity;
import com.virtualbox.torchick.rog.instance.Berita;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class RecycleAdapterBerita extends RecyclerView.Adapter<RecycleAdapterBerita.BeritaViewHolder> {

    private List<Berita> beritaList = new ArrayList<>();
    private Context mContext;
    View view;
    String satker;

    public RecycleAdapterBerita(List<Berita> beritaList, Context context, String satker){

       this.beritaList = beritaList;
        this.mContext = context;
        this.satker =satker;
    }


    @Override
    public BeritaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_berita_item,parent,false);

        return new BeritaViewHolder(view);
    }

    public static String geTkey1(){
        return "5FE882F5E894E5D3070B7607285260220";
    }

    @Override
    public void onBindViewHolder(BeritaViewHolder holder, int position) {
        holder.tanggal_rilis.setText("Tanggal Rilis : "+ beritaList.get(position).getRl_date());
        holder.kategori.setText("Kategori : "+ beritaList.get(position).getNewscat_name());
        final CharSequence id_news = beritaList.get(position).getnews_id();
        final CharSequence p = beritaList.get(position).getTitle();
        holder.title.setText(p);

//        Picasso.with(mContext)
//                .load(beritaList.get(position).getCover())
//                .placeholder(R.drawable.load)
//                .error(R.drawable.bps)
//                .into(holder.imageView);

        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                CharSequence text = ""+p;
//                int duration = Toast.LENGTH_SHORT;
//
//                Toast toast = Toast.makeText(mContext, text, duration);
//                toast.show();
                Intent intent = new Intent(v.getContext(), DetailBeritaActivity.class);
                intent.putExtra("id_news", id_news);
                v.getContext().startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        return beritaList.size();
    }

    public static class BeritaViewHolder extends  RecyclerView.ViewHolder{

        TextView kategori, tanggal_rilis,title;
        ImageView imageView;
        // FloatingActionButton floatingActionButton;

        public BeritaViewHolder(View itemView) {
            super(itemView);

            tanggal_rilis = (TextView)itemView.findViewById(R.id.tanggal_rilis);
            kategori = (TextView)itemView.findViewById(R.id.kategori);


            title = (TextView)itemView.findViewById(R.id.title);
            //imageView = (ImageView) itemView.findViewById(R.id.imageViewPublikasi);
            // floatingActionButton = (FloatingActionButton)itemView.findViewById(R.id.buttonDowmnload);

        }
    }
}
