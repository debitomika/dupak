package com.virtualbox.torchick.rog.instance.Detail;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DetailTabelDinamisVar {
    @SerializedName("val")
    private String val;
    @SerializedName("label")
    private String label;
    @SerializedName("unit")
    private String unit;
    @SerializedName("subj")
    private String subj;
    @SerializedName("def")
    private String def;
    @SerializedName("note")
    private String note;

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getSubj() {
        return subj;
    }

    public void setSubj(String subj) {
        this.subj = subj;
    }

    public String getDef() {
        return def;
    }

    public void setDef(String def) {
        this.def = def;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
