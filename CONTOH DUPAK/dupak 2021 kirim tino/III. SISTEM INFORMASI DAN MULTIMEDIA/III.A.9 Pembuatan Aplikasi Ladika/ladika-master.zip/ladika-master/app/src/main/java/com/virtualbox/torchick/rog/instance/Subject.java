package com.virtualbox.torchick.rog.instance;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class Subject {

    @SerializedName("sub_id")
    private String sub_id;
    @SerializedName("title")
    private String title;
    @SerializedName("n_table")
    private String n_tabel;

    public String getSub_id() {
        return sub_id;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getN_tabel() {
        return n_tabel;
    }

    public void setN_tabel(String n_tabel) {
        this.n_tabel = n_tabel;
    }

}
