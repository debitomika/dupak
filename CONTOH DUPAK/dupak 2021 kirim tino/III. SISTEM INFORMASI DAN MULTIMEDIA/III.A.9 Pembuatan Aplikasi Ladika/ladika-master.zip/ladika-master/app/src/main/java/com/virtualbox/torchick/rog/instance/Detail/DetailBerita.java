package com.virtualbox.torchick.rog.instance.Detail;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DetailBerita {
    @SerializedName("news_id")
    private String news_id;
    @SerializedName("news_type")
    private String news_type;
    @SerializedName("title")
    private String title;
    @SerializedName("news")
    private String news;
    @SerializedName("rl_date")
    private String rl_date;
    @SerializedName("picture")
    private String picture;

    public String getnews_id() {
        return news_id;
    }

    public void setNews_id(String news_id) {
        this.news_id = news_id;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNews_type() {
        return news_type;
    }

    public void setNews_type(String news_type) {
        this.news_type = news_type;
    }

    public String getNews() {
        return news;
    }

    public void setNews(String news) {
        this.news = news;
    }

    public String getRl_date() {
        return rl_date;
    }

    public void setRl_date(String rl_date) {
        this.rl_date = rl_date;
    }

}
