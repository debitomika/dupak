package com.virtualbox.torchick.rog;

import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.virtualbox.torchick.rog.R;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class PagerFragment extends Fragment {

    private static final String KEY_DRAWABLE = "DRAWABLE";

    public static PagerFragment instance(@DrawableRes int drawableId) {
        Bundle args = new Bundle();
        args.putInt(KEY_DRAWABLE, drawableId);
        PagerFragment fragment = new PagerFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.pager_item_et, container, false);
        ImageView imageView = (ImageView) view.findViewById(R.id.image);
        imageView.setImageDrawable(getContext().getResources().getDrawable(getArguments().getInt(KEY_DRAWABLE)));
        return view;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);
    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
    }
}
