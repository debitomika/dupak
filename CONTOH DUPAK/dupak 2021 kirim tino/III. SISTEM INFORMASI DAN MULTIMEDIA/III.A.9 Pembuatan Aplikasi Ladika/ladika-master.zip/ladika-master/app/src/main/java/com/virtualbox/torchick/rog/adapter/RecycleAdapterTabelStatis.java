package com.virtualbox.torchick.rog.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.instance.TabelStatis;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class RecycleAdapterTabelStatis extends RecyclerView.Adapter<RecycleAdapterTabelStatis.TabelStatisViewHolder> {

    private List<TabelStatis> tabelStatisList = new ArrayList<>();
    private Context mContext;
    View view;
    String satker;

    public RecycleAdapterTabelStatis(List<TabelStatis> tabelStatisList, Context context, String satker){

       this.tabelStatisList = tabelStatisList;
        this.mContext = context;
        this.satker =satker;
    }


    @Override
    public TabelStatisViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_tabelstatis_item,parent,false);

        return new TabelStatisViewHolder(view);
    }

    public static String geTkey1(){
        return "5FE882F5E894E5D3070B7607285260220";
    }

    @Override
    public void onBindViewHolder(TabelStatisViewHolder holder, int position) {
        holder.issn.setText("ISSN/ISBN : "+ tabelStatisList.get(position).getUpdt_date());
        holder.rl_date.setText("Release Date : "+ tabelStatisList.get(position).getUpdt_date());
        final CharSequence p = tabelStatisList.get(position).getTitle();
        holder.title.setText(p);

//        Picasso.with(mContext)
//                .load(tabelStatisList.get(position).getCover())
//                .placeholder(R.drawable.load)
//                .error(R.drawable.bps)
//                .into(holder.imageView);

        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence text = ""+p;
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(mContext, text, duration);
                toast.show();
            }
        });
    }



    @Override
    public int getItemCount() {
        return tabelStatisList.size();
    }

    public static class TabelStatisViewHolder extends  RecyclerView.ViewHolder{

        TextView issn, rl_date,title;
        ImageView imageView;
        // FloatingActionButton floatingActionButton;

        public TabelStatisViewHolder(View itemView) {
            super(itemView);

            rl_date = (TextView)itemView.findViewById(R.id.rl_date);
            issn = (TextView)itemView.findViewById(R.id.issn);


            title = (TextView)itemView.findViewById(R.id.title);
            imageView = (ImageView) itemView.findViewById(R.id.imageViewPublikasi);
            // floatingActionButton = (FloatingActionButton)itemView.findViewById(R.id.buttonDowmnload);

        }
    }
}
