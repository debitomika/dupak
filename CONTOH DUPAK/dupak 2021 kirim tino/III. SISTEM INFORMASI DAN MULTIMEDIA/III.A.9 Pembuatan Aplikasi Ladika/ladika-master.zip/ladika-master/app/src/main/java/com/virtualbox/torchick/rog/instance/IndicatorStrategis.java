package com.virtualbox.torchick.rog.instance;

public class IndicatorStrategis {
    private int id;
    private String judul;
    private String tanggal;
    private float nilai;

    public IndicatorStrategis() {

    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public float getNilai() {
        return nilai;
    }

    public void setNilai(float nilai) {
        this.nilai = nilai;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public IndicatorStrategis(int id, String judul, float nilai, String tanggal) {
        this.id = id;
        this.judul = judul;
        this.nilai = nilai;
        this.tanggal = tanggal;
    }

}