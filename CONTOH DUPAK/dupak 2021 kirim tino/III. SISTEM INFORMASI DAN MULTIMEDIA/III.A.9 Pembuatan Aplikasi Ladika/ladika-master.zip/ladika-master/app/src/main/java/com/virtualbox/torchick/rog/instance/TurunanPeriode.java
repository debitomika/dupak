package com.virtualbox.torchick.rog.instance;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class TurunanPeriode {

    @SerializedName("turth_id")
    private String turth_id;
    @SerializedName("turth")
    private String turth;
    @SerializedName("group_turth_id")
    private String group_turth_id;
    @SerializedName("name_group_turth_id")
    private String name_group_turth_id;

    public String getTurth_id() {
        return turth_id;
    }

    public void setTurth_id(String turth_id) {
        this.turth_id = turth_id;
    }

    public String getTurth() {
        return turth;
    }

    public void setTurth(String turth) {
        this.turth = turth;
    }

    public String getGroup_turth_id() {
        return group_turth_id;
    }

    public void setGroup_turth_id(String group_turth_id) {
        this.group_turth_id = group_turth_id;
    }

    public String getName_group_turth_id() {
        return name_group_turth_id;
    }

    public void setName_group_turth_id(String name_group_turth_id) {
        this.name_group_turth_id = name_group_turth_id;
    }
}
