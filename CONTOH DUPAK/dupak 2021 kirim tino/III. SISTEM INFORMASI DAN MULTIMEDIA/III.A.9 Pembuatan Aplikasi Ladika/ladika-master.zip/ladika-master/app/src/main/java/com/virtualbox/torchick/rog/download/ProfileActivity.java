package com.virtualbox.torchick.rog.download;

import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.helper.DBHelper;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

public class ProfileActivity extends AppCompatActivity {

    private String token;
    private String pdfurl, idpdf;
    private AutoCompleteTextView email;
    private EditText password;
    private CheckBox remember;
    private CoordinatorLayout coordinatorLayout;
    private DBHelper DBHelper;
    private SQLiteDatabase sqLiteDatabase;
    private Cursor cursor;
    private String email2, password2, uname, pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        DBHelper = new DBHelper(this);
        getAuth();
        Button login = (Button) findViewById(R.id.btnLogin);
        TextView registrasi = (TextView) findViewById(R.id.registrasi);
        email = (AutoCompleteTextView) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinatorLayoutDownload);
        remember = (CheckBox) findViewById(R.id.checkRememberMe);


//        if(uname==null || uname.isEmpty()) {
//            registrasi.setOnClickListener(new View.OnClickListener() {
//
//                @Override
//                public void onClick(View v) {
//                    Intent browserIntent = new Intent(Intent.ACTION_VIEW);
//                    browserIntent.setData(Uri.parse("https://webapi.bps.go.id/consumen/1f5ea27aa195656fa79ee36110bda985#tab2"));
//                    startActivity(browserIntent);
//                }
//            });
//
//            login.setOnClickListener(new View.OnClickListener() {
//
//                @Override
//                public void onClick(View v) {
//                    email2 = email.getText().toString();
//                    password2 = password.getText().toString();
//                    if (email2.isEmpty()) {
//                        Snackbar.make(coordinatorLayout, "Email harus terisi...", Snackbar.LENGTH_LONG).show();
//                    } else if (password2.isEmpty()) {
//                        Snackbar.make(coordinatorLayout, "Password harus terisi...", Snackbar.LENGTH_LONG).show();
//                    } else if (!email2.isEmpty()) {
//                        if (email2.contains("@")) {
//                            try {
//                                new JsoupLoginProfile(ProfileActivity.this, email2, password2).execute();
//                            } catch (Exception e) {
////                                e.printStackTrace();
//                                Snackbar.make(coordinatorLayout, e.getMessage(), Snackbar.LENGTH_LONG).show();
//                            }
//                        } else {
//                            Snackbar.make(coordinatorLayout, "Harap isikan alamat email yang benar!", Snackbar.LENGTH_LONG).show();
//                        }
//                    }
//
//                }
//            });
//        }else{
//            try {
//                new JsoupLoginProfile(ProfileActivity.this, uname, pass).execute();
//            } catch (Exception e) {
////                                e.printStackTrace();
//                Snackbar.make(coordinatorLayout, e.getMessage(), Snackbar.LENGTH_LONG).show();
//            }
//        }
        Intent intent = getIntent();
        pdfurl = intent.getStringExtra("pdfurl");
        idpdf = intent.getStringExtra("idpdf");

        String urls = pdfurl;
        try {
            URL url = new URL(urls);
            String pathr = url.getPath();
            String filename = pathr.substring(pathr.lastIndexOf('/') + 1);
            File file = new File(Environment.getExternalStorageDirectory(), filename);

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        DownloadManager.Request r = new DownloadManager.Request(Uri.parse(urls));
        r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, idpdf);
        r.allowScanningByMediaScanner();

        r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        dm.enqueue(r);

        finish();
//    } catch (MalformedURLException e) {
//        e.printStackTrace();
//    }

    }

    public void afterGetToken(String token) {

        if (!token.isEmpty()) {

            setToken(token);
            final String urls = pdfurl + getToken();
            if(remember.isChecked()) {
                setAuth(email2, password2);
            }
            try {

                URL url = new URL(urls);
                String pathr = url.getPath();
                String filename = pathr.substring(pathr.lastIndexOf('/') + 1);
                File file = new File(Environment.getExternalStorageDirectory(), filename);


            } catch (MalformedURLException e) {
                e.printStackTrace();
            }

            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(urls));
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, idpdf);
            r.allowScanningByMediaScanner();

            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            dm.enqueue(r);

            finish();


        }else{
            Snackbar.make(coordinatorLayout, "Email/Password salah, silahkan coba lagi", Snackbar.LENGTH_LONG)
                    .show();
        }


    }


    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:

                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void getAuth(){
        sqLiteDatabase = DBHelper.getReadableDatabase();
        cursor = sqLiteDatabase.rawQuery("SELECT * FROM auth", null);
        cursor.moveToFirst();
        do {
            this.uname =  cursor.getString(1);
            this.pass =  cursor.getString(2);
        } while (cursor.moveToNext());
        DBHelper.close();
    }

    private boolean setAuth(String email, String password) {
        sqLiteDatabase = DBHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("password",password);
        sqLiteDatabase.update("auth", contentValues, "id = ?", new String[] { "1" });
        return true;
    }
}
