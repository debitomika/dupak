package com.virtualbox.torchick.rog.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.adapter.RecycleAdapterDaftarTabel;
import com.virtualbox.torchick.rog.instance.Deskripsi;
import com.virtualbox.torchick.rog.instance.DaftarTabel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class FragmentDaftarTabel extends Fragment {

    private RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    List<DaftarTabel> daftarTabelListAll = new ArrayList<>();
    ImageView imageView;
    private RecycleAdapterDaftarTabel daftarTabelRecycleAdapter;
    String Satker, Key;


    private int page;
    private int currentpage;

    int lastPos;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActivity().setTitle(getArguments().getString("title"));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tabelstatis, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewList);
        imageView = (ImageView) view.findViewById(R.id.imageViewLoading);

        Glide.with(getContext())
                .load(R.drawable.load)
                .into(imageView);

        linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        refreshSatker();
        return view;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser) {

            if ((MainActivity) getActivity() != null) {
                // ((MainActivity) getActivity()).setListActionBar();
            }

        }
    }

    public void refreshSatker() {

        imageView.setVisibility(View.VISIBLE);

        daftarTabelListAll.clear();
        lastPos = daftarTabelListAll.size();

        getDaftarTabel();

        setCurrentpage(2);


        recyclerView.addOnScrollListener(new EndlessRecyclerOnScrollListener(linearLayoutManager) {


            @Override
            public void onLoadMore(int current_page) {

                if (getCurrentpage() < getPage()) {
                    lastPos = daftarTabelListAll.size();
                    getDaftarTabelByPage(String.valueOf(getCurrentpage()));
                    setCurrentpage(getCurrentpage() + 1);

                }

            }

        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    private void getDaftarTabel() {

        Satker = ((MainActivity) getActivity()).getSatker();
        Key = ((MainActivity) getActivity()).getKey();

        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=statictable&domain=" + Satker + "&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {
                            System.out.println("csc1");

                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");

                            JSONObject des = data.getJSONObject(0);

                            String stringdes = des.toString();

                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();

                            Deskripsi desc = gson.fromJson(stringdes, Deskripsi.class);
//                            Toast toast = Toast.makeText(getActivity(), desc.getPages(), Toast.LENGTH_LONG);
//                            toast.show();
                            for(int i= 1; i<=Integer.valueOf(desc.getPages()); i++){
                                getDaftarTabelByPage(String.valueOf(i));
                            }
                            //setPage(Integer.valueOf(desc.getPages()) + 1);

                            //getDaftarTabelByPage("1");

                        } catch (JSONException e) {

                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });


        PubSingleton.getmInstance(getContext()).addToRequestQueue(stringRequest);


    }

    private void getDaftarTabelByPage(final String page) {



        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=statictable&domain=" + Satker + "&page=" + page + "&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");

                            JSONArray tabelStatis = data.getJSONArray(1);
                            String stringpub = tabelStatis.toString();

                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();

                            List<DaftarTabel> brsList = Arrays.asList(gson.fromJson(stringpub, DaftarTabel[].class));
                            List<DaftarTabel> brsList2 = new ArrayList<DaftarTabel>();
                            for(int i=0; i<brsList.size();i++){
                                int idx=0;
                                if(brsList.get(i).getSubj_id().toString().equals(getArguments().getString("id_sub"))){
                                    brsList2.add(idx, brsList.get(i));
                                }
                            }
                            daftarTabelListAll.addAll(brsList2);

//                            Collections.sort(daftarTabelListAll, new Comparator<DaftarTabel>() {
//                                @Override
//                                public int compare(DaftarTabel one, DaftarTabel two) {
//
//                                    int oneRD = Integer.valueOf(one.getUpdt_date().replace("-", ""));
//                                    int twoRD = Integer.valueOf(two.getUpdt_date().replace("-", ""));
//                                    return oneRD > twoRD ? -1 : (oneRD < twoRD) ? 1 : 0;
//                                }
//                            });

                            daftarTabelRecycleAdapter = new RecycleAdapterDaftarTabel(daftarTabelListAll, getContext(), Satker);
                            daftarTabelRecycleAdapter.notifyDataSetChanged();
                            recyclerView.setAdapter(daftarTabelRecycleAdapter);
                            recyclerView.scrollToPosition(lastPos);
                            imageView.setVisibility(View.GONE);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        PubSingleton.getmInstance(getContext()).addToRequestQueue(stringRequest);


    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getCurrentpage() {
        return currentpage;
    }

    public void setCurrentpage(int currentpage) {
        this.currentpage = currentpage;
    }

    public abstract class EndlessRecyclerOnScrollListener extends RecyclerView.OnScrollListener {
        public String TAG = EndlessRecyclerOnScrollListener.class.getSimpleName();

        private int previousTotal = 0; // The total number of items in the dataset after the last load
        private boolean loading = true; // True if we are still waiting for the last set of data to load.
        private int visibleThreshold = 1; // The minimum amount of items to have below your current scroll position before loading more.
        int firstVisibleItem, visibleItemCount, totalItemCount;

        private int current_page = 1;

        private LinearLayoutManager mLinearLayoutManager;

        public EndlessRecyclerOnScrollListener(LinearLayoutManager linearLayoutManager) {
            this.mLinearLayoutManager = linearLayoutManager;
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);

            visibleItemCount = recyclerView.getChildCount();
            totalItemCount = mLinearLayoutManager.getItemCount();
            firstVisibleItem = mLinearLayoutManager.findFirstVisibleItemPosition();

            if (loading) {
                if (totalItemCount > previousTotal) {
                    loading = false;
                    previousTotal = totalItemCount;
                }
            }
            if (!loading && (totalItemCount - visibleItemCount)
                    <= (firstVisibleItem + visibleThreshold)) {

                current_page++;

                onLoadMore(current_page);

                loading = true;
            }
        }

        public abstract void onLoadMore(int current_page);
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {

        public List<Fragment> mFragmentList = new ArrayList<>();
        public final List<String> mFragmentTitleList = new ArrayList<>();

        FragmentManager manager;

        public ViewPagerAdapter(FragmentManager manager) {

            super(manager);
            this.manager = manager;

        }

        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);


        }

        public void replaceFragment(Fragment fragment, int index) {

            mFragmentList.remove(index);
            mFragmentList.add(index, fragment);

            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFrag(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }


    }
}
