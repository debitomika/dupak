package com.virtualbox.torchick.rog.activity;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.squareup.picasso.Picasso;
import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.instance.Detail.DetailBerita;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Yusfil Pulungan on 3/20/2018.
 */

public class DetailBeritaActivity extends AppCompatActivity {
    private String Satker, Key;
    private String Id_news;
    private ImageView imageView;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        Intent intent=getIntent();
        this.Id_news = intent.getStringExtra("id_news");
        ActionBar ab = getSupportActionBar();
        ab.setDisplayShowHomeEnabled(true);
        ab.setDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.detailberitaactivity_main);
        setTitle("Detail Berita");
        imageView = (ImageView) findViewById(R.id.imageViewLoading);
        Glide.with(DetailBeritaActivity.this)
                .load(R.drawable.load)
                .into(imageView);
        getDetailBerita();
    }

    private void getDetailBerita() {

        Satker = MainActivity.SATKER;
        Key = MainActivity.KEY;

        String server_url = "https://webapi.bps.go.id/v1/api/view/?model=news&id="+this.Id_news+"&lang=ind&domain=" + Satker + "&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {
                            JSONObject alldata = new JSONObject(response);
                            JSONObject des = alldata.getJSONObject("data");
                            String stringdes = des.toString();

                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();
                            DetailBerita detailBerita = gson.fromJson(stringdes, DetailBerita.class);

                            TextView tvName = findViewById(R.id.title_news);
                            TextView tanggal_rilis = findViewById(R.id.rl_date);
                            tvName.setText(detailBerita.getTitle());
                            tanggal_rilis.setText("Diunggah tanggal : "+detailBerita.getRl_date());
                            WebView wbName = findViewById(R.id.detail_news);
                            wbName.getSettings().setJavaScriptEnabled(true);
                            String html = "<html><body style='text-alignment:justify'>"+detailBerita.getNews()+"</body></html>";
                            String encodedHtml = Html.fromHtml(html).toString();
                            wbName.loadData(encodedHtml, "text/html", null);
                            ImageView picture = (ImageView) findViewById(R.id.picture);
                            Picasso.with(DetailBeritaActivity.this)
                                .load(detailBerita.getPicture())
                                .placeholder(R.drawable.load)
                                .error(R.drawable.bps)
                                .into(picture);
                            imageView.setVisibility(View.GONE);
                        } catch (JSONException e) {
                            Toast.makeText(DetailBeritaActivity.this,"error",Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        PubSingleton.getmInstance(DetailBeritaActivity.this).addToRequestQueue(stringRequest);
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {
            this.finish();
        } else {
            super.onBackPressed(); //replaced
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}