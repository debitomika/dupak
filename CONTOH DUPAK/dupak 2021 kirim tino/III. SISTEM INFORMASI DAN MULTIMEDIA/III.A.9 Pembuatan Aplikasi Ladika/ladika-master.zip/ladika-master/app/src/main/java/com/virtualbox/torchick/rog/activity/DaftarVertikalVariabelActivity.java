package com.virtualbox.torchick.rog.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.SparseBooleanArray;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.instance.Deskripsi;
import com.virtualbox.torchick.rog.instance.VertikalVariabel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DaftarVertikalVariabelActivity extends AppCompatActivity {
    private String Satker, Key;
    private String Id_var, Id_turvar, Id_periode, Id_turunanperiode, Judul_tabel, Notes;
    private ImageView imageView;
    private Button btn_next;
    private String vervarParam="";
    ListView vervarListView;
    private CheckBox select_all;
    private List<VertikalVariabel> vervarListAll = new ArrayList<>();
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        Intent intent=getIntent();
        this.Id_var = intent.getStringExtra("id_variabel");
        this.Id_turvar = intent.getStringExtra("id_turvar");
        this.Id_periode = intent.getStringExtra("id_periode");
        this.Id_turunanperiode = intent.getStringExtra("id_turunanperiode");
        this.Judul_tabel = intent.getStringExtra("judul_tabel");
        this.Notes = intent.getStringExtra("notes");
        ActionBar ab = getSupportActionBar();
        ab.setDisplayShowHomeEnabled(true);
        ab.setDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.vertikalvariabelactivity_main);
        setTitle("Vertikal Variabel");
        vervarListView = (ListView) findViewById(R.id.listVerticalVariabel);
        imageView = (ImageView) findViewById(R.id.imageViewLoading);
        btn_next = (Button) findViewById(R.id.btn_next);
        btn_next.setVisibility(View.GONE);
        Glide.with(DaftarVertikalVariabelActivity.this)
                .load(R.drawable.load)
                .into(imageView);
        select_all = (CheckBox) findViewById(R.id.checkall);
        select_all.setVisibility(View.GONE);
        select_all.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(select_all.isChecked())
                {
                    for ( int i=0; i < vervarListView.getCount(); i++) {
                        vervarListView.setItemChecked(i, true);
                    }
                }
                if(!select_all.isChecked())
                {
                    for ( int i=0; i < vervarListView.getCount(); i++) {
                        vervarListView.setItemChecked(i, false);
                    }
                }

            }
        });
        getVertikalVariabel();
    }

    private void getVertikalVariabel() {

        Satker = MainActivity.SATKER;
        Key = MainActivity.KEY;

        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=vervar&var="+this.Id_var+"&domain="+Satker+"&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject alldata = new JSONObject(response);
                            String des = alldata.getString("data");
                            TextView size = findViewById(R.id.size);

                            LinearLayout vervarLinierLayout=findViewById(R.id.vervarLinierLayout);
                            if(des.matches("")) {
                                vervarLinierLayout.setGravity(Gravity.CENTER);
                                vervarListView.setVisibility(View.GONE);
                                select_all.setVisibility(View.GONE);
                                size.setText("Tidak memiliki vertikal variabel");
                            }else {
                                size.setVisibility(View.GONE);
                                vervarLinierLayout.setGravity(Gravity.TOP);
                                JSONArray data = alldata.getJSONArray("data");
//                                JSONArray turvar = data.getJSONArray(1);
                                JSONObject deskripsi = data.getJSONObject(0);

                                GsonBuilder builder = new GsonBuilder();
                                Gson gson = builder.create();

                                Deskripsi desc = gson.fromJson(deskripsi.toString(), Deskripsi.class);
                                for (int i = 1; i <= Integer.valueOf(desc.getPages()); i++) {
                                    getDaftarVerVarByPage(String.valueOf(i));
                                }

                                select_all.setVisibility(View.VISIBLE);
                            }
                            imageView.setVisibility(View.GONE);
                            btn_next.setVisibility(View.VISIBLE);
                        } catch (JSONException e) {
                            Toast.makeText(DaftarVertikalVariabelActivity.this,"error",Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        PubSingleton.getmInstance(DaftarVertikalVariabelActivity.this).addToRequestQueue(stringRequest);
    }

    private void getDaftarVerVarByPage(final String page) {

        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=vervar&var="+this.Id_var+"&page="+page+"&domain="+Satker+"&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");
                            JSONArray turvar = data.getJSONArray(1);
                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();
                            List<VertikalVariabel> periodeList = Arrays.asList(gson.fromJson(turvar.toString(),VertikalVariabel[].class));
                            vervarListAll.addAll(periodeList);
                            List<String> periodeString = new ArrayList<String>();
                            for(int i=0; i<vervarListAll.size(); i++){
                                periodeString.add(vervarListAll.get(i).getVervar());
                            }
                            vervarListView.setChoiceMode(vervarListView.CHOICE_MODE_MULTIPLE);
                            vervarListView.setTextFilterEnabled(true);

                            ArrayAdapter<String> adapter = new ArrayAdapter<String>
                                    (DaftarVertikalVariabelActivity.this,
                                            android.R.layout.simple_list_item_multiple_choice,
                                            android.R.id.text1, periodeString);

                            vervarListView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        PubSingleton.getmInstance(DaftarVertikalVariabelActivity.this).addToRequestQueue(stringRequest);


    }

    public void goDetailTabelDinamis(View v){
        if(!vervarListAll.isEmpty()) {
            String param = "";
            for (int i = 0; i < vervarListAll.size(); i++) {
                if (vervarListView.isItemChecked(i)) {
                    param += ";" + vervarListAll.get(i).getKode_ver_id();
                }
            }
            if (param.isEmpty()) {
                vervarParam = "";
            } else {
                vervarParam = param.substring(1);
            }
        }

        Intent intent = new Intent(v.getContext(), DetailTabelDinamisActivity.class);
        intent.putExtra("id_variabel", this.Id_var);
        intent.putExtra("id_turvar", this.Id_turvar);
        intent.putExtra("id_periode", this.Id_periode);
        intent.putExtra("id_turunanperiode", this.Id_turunanperiode);
        intent.putExtra("id_vervar", this.vervarParam);
        intent.putExtra("judul_tabel", this.Judul_tabel);
        intent.putExtra("notes", this.Notes);
        v.getContext().startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {
            this.finish();
        } else {
            super.onBackPressed(); //replaced
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}

