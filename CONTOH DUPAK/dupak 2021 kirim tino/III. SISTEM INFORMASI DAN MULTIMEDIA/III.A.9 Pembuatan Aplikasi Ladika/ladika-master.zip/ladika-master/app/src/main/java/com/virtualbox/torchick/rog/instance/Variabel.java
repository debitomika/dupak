package com.virtualbox.torchick.rog.instance;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class Variabel {

    @SerializedName("sub_id")
    private String sub_id;
    @SerializedName("title")
    private String title;

    public String getSub_id() {
        return sub_id;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}
