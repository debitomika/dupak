package com.virtualbox.torchick.rog.instance;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DaftarTabelDinamis {

    @SerializedName("table_id")
    private String table_id;
    @SerializedName("subj_id")
    private String subj_id;
    @SerializedName("subj")
    private String subj;
    @SerializedName("title")
    private String title;
    @SerializedName("updt_date")
    private String updt_date;

    public String getTable_id() {
        return table_id;
    }

    public void setTable_id(String table_id) {
        this.table_id = table_id;
    }

    public String getSubj_id() {
        return subj_id;
    }

    public void setSubj_id(String subj_id) {
        this.subj_id = subj_id;
    }

    public String getSubj() {
        return subj;
    }

    public void setSubj(String subj) {
        this.subj = subj;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUpdt_date() {
        return updt_date;
    }

    public void setUpdt_date(String updt_date) {
        this.updt_date = updt_date;
    }

}
