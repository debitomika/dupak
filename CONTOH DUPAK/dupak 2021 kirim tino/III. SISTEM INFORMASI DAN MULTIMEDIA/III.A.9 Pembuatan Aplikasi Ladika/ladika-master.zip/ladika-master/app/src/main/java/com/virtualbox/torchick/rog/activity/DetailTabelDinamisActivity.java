package com.virtualbox.torchick.rog.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.instance.Detail.DetailTabelDinamisVar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static android.widget.Toast.LENGTH_LONG;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DetailTabelDinamisActivity extends AppCompatActivity {
    private String Satker, Key;
    private String Id_var, Id_turvar, Id_periode, Id_turunanperiode, Id_vervar, Judul_tabel, Notes;
    private ImageView imageView;
    private TextView judul, note;
    private String url="";
    ProgressDialog mProgressBar;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        Intent intent=getIntent();
        this.Id_var = intent.getStringExtra("id_variabel");
        this.Id_turvar = intent.getStringExtra("id_turvar");
        this.Id_periode = intent.getStringExtra("id_periode");
        this.Id_turunanperiode = intent.getStringExtra("id_turunanperiode");
        this.Id_vervar = intent.getStringExtra("id_vervar");
        this.Judul_tabel = intent.getStringExtra("judul_tabel");
        this.Notes = intent.getStringExtra("notes");
        ActionBar ab = getSupportActionBar();
        ab.setDisplayShowHomeEnabled(true);
        ab.setDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.detailtabeldinamisactivity_main);
        setTitle("Detail Tabel");
        imageView = (ImageView) findViewById(R.id.imageViewLoading);
        judul = (TextView) findViewById(R.id.judul);
        note = (TextView) findViewById(R.id.notes);

        getDetailTabel();

        mProgressBar = new ProgressDialog(this);

        getDetailTabel();
    }

    private void getDetailTabel() {

        Satker = MainActivity.SATKER;
        Key = MainActivity.KEY;
        url = "https://sultradata.com/tabeldinamis/index.php/?var="+this.Id_var+"&turvar="+this.Id_turvar+"&vervar="+this.Id_vervar+"&th="+this.Id_periode+"&turth="+this.Id_turunanperiode+"&lang=ind&domain=" + Satker + "&key="+Key;
        //        judul.setText(url);
                        try {
                            WebView wbName = findViewById(R.id.detail_news);
                            wbName.loadUrl(url);
                            wbName.setWebChromeClient(new WebChromeClient() {
                                public void onProgressChanged(WebView view, int progress) {
                                    Glide.with(DetailTabelDinamisActivity.this)
                                            .load(R.drawable.load)
                                            .into(imageView);
                                    if(progress == 100)
                                        judul.setText(Judul_tabel);
                                        note.setText(Notes);
                                        imageView.setVisibility(View.GONE);
                                } });
                        }catch (Exception e) {
                            imageView.setVisibility(View.GONE);
                        }
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {
            this.finish();
        } else {
            super.onBackPressed(); //replaced
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}

