package com.virtualbox.torchick.rog.snapbar;

import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.activity.DetailBeritaActivity;
import com.virtualbox.torchick.rog.fragment.FragmentBerita;
import com.virtualbox.torchick.rog.fragment.FragmentBrs;
import com.virtualbox.torchick.rog.fragment.FragmentIndikatorStrategis;
import com.virtualbox.torchick.rog.fragment.FragmentInfografis;
import com.virtualbox.torchick.rog.fragment.FragmentListTabelDinamis;
import com.virtualbox.torchick.rog.fragment.FragmentPublikasi;
import com.virtualbox.torchick.rog.fragment.FragmentTabelDinamis;
import com.virtualbox.torchick.rog.fragment.FragmentTabelStatis;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<App> mApps;
    private boolean mHorizontal;
    private boolean mPager;

    public Adapter(boolean horizontal, boolean pager, List<App> apps) {
        mHorizontal = horizontal;
        mApps = apps;
        mPager = pager;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (mPager) {
            return new ViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.adapter_pager, parent, false));
        } else {
            return mHorizontal ? new ViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.adapter, parent, false)) :
                    new ViewHolder(LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.adapter_vertical, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        App app = mApps.get(position);
        holder.imageView.setImageResource(app.getDrawable());
        holder.nameTextView.setText(app.getName());
        if(app.getNotif()!=null&&Integer.parseInt(app.getNotif())>0){
            holder.notifTextView.setText("+"+app.getNotif());
        }else{
            holder.notifTextView.setVisibility(View.INVISIBLE);
        }

    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public int getItemCount() {
        return mApps.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public ImageView imageView;
        public TextView nameTextView;
        public TextView ratingTextView;
        public TextView notifTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            imageView = (ImageView) itemView.findViewById(R.id.imageView);
            nameTextView = (TextView) itemView.findViewById(R.id.nameTextView);
            ratingTextView = (TextView) itemView.findViewById(R.id.ratingTextView);
            notifTextView = (TextView) itemView.findViewById(R.id.textNotif);

        }

        @Override
        public void onClick(View v) {
            Log.d("App", mApps.get(getAdapterPosition()).getName());
            FragmentManager fragmentManager = ((FragmentActivity) v.getContext()).getSupportFragmentManager();
            if(getAdapterPosition()==6){
                FragmentBerita fragmentBerita= new FragmentBerita();
                fragmentManager.beginTransaction()
                        .replace(R.id.frame_container, fragmentBerita, null)
                        .addToBackStack(null)
                        .commit();
            }else if(getAdapterPosition()==0){
                FragmentBrs fragmentBrs= new FragmentBrs();
                fragmentManager.beginTransaction()
                        .replace(R.id.frame_container, fragmentBrs, null)
                        .addToBackStack(null)
                        .commit();
            }else if(getAdapterPosition()==1){
                FragmentPublikasi fragmentPublikasi= new FragmentPublikasi();
                fragmentManager.beginTransaction()
                        .replace(R.id.frame_container, fragmentPublikasi, null)
                        .addToBackStack(null)
                        .commit();
            }else if(getAdapterPosition()==5){
                FragmentIndikatorStrategis fragmentIndikatorStrategis= new FragmentIndikatorStrategis();
                fragmentManager.beginTransaction()
                        .replace(R.id.frame_container, fragmentIndikatorStrategis, null)
                        .addToBackStack(null)
                        .commit();
            }else if(getAdapterPosition()==2){
                FragmentTabelStatis fragmentTabelStatis= new FragmentTabelStatis();
                fragmentManager.beginTransaction()
                        .replace(R.id.frame_container, fragmentTabelStatis, null)
                        .addToBackStack(null)
                        .commit();
            }else if(getAdapterPosition()==3){
//                FragmentTabelDinamis fragmentTabelDinamis= new FragmentTabelDinamis();
                FragmentListTabelDinamis fragmentTabelDinamis= new FragmentListTabelDinamis();
                fragmentManager.beginTransaction()
                        .replace(R.id.frame_container, fragmentTabelDinamis, null)
                        .addToBackStack(null)
                        .commit();
            }else if(getAdapterPosition()==4) {
                FragmentTabelDinamis fragmentTabelDinamis= new FragmentTabelDinamis();
                fragmentManager.beginTransaction()
                        .replace(R.id.frame_container, fragmentTabelDinamis, null)
                        .addToBackStack(null)
                        .commit();
            }else if(getAdapterPosition()==7){
                FragmentInfografis fragmentInfografis= new FragmentInfografis();
                fragmentManager.beginTransaction()
                        .replace(R.id.frame_container, fragmentInfografis, null)
                        .addToBackStack(null)
                        .commit();
            }
        }
    }

}

