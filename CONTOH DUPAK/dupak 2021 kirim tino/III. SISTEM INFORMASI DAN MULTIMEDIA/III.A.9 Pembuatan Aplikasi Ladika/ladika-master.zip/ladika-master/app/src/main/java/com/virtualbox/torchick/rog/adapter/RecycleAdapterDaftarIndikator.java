package com.virtualbox.torchick.rog.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.activity.DaftarTurunanVariabelActivity;
import com.virtualbox.torchick.rog.instance.DaftarVariabel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class RecycleAdapterDaftarIndikator extends RecyclerView.Adapter<RecycleAdapterDaftarIndikator.DaftarVariabelViewHolder> {

    private List<DaftarVariabel> daftarVariabelList = new ArrayList<>();
    private Context mContext;
    View view;
    String satker;

    public RecycleAdapterDaftarIndikator(List<DaftarVariabel> daftarVariabelList, Context context, String satker){

        this.daftarVariabelList = daftarVariabelList;
        this.mContext = context;
        this.satker =satker;
    }


    @Override
    public DaftarVariabelViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_daftarvariabel_item,parent,false);

        return new DaftarVariabelViewHolder(view);
    }

    public static String geTkey1(){
        return "5FE882F5E894E5D3070B7607285260220";
    }

    @Override
    public void onBindViewHolder(DaftarVariabelViewHolder holder, int position) {
        final String id_var = daftarVariabelList.get(position).getVar_id();
        final CharSequence p = daftarVariabelList.get(position).getTitle();
        final String judul = daftarVariabelList.get(position).getTitle()+" ("+daftarVariabelList.get(position).getUnit()+")";
        final String note = daftarVariabelList.get(position).getNotes();
        holder.title.setText(p);

//        Picasso.with(mContext)
//                .load(daftarVariabelList.get(position).getCover())
//                .placeholder(R.drawable.load)
//                .error(R.drawable.bps)
//                .into(holder.imageView);

        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DaftarTurunanVariabelActivity.class);
                intent.putExtra("id_variabel", id_var);
                intent.putExtra("judul_tabel", judul);
                intent.putExtra("notes", note);
                v.getContext().startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        return daftarVariabelList.size();
    }

    public static class DaftarVariabelViewHolder extends  RecyclerView.ViewHolder{

        TextView title;
        ImageView imageView;
        // FloatingActionButton floatingActionButton;

        public DaftarVariabelViewHolder(View itemView) {
            super(itemView);

            title = (TextView)itemView.findViewById(R.id.title);
            imageView = (ImageView) itemView.findViewById(R.id.imageViewPublikasi);
            // floatingActionButton = (FloatingActionButton)itemView.findViewById(R.id.buttonDowmnload);

        }
    }
}
