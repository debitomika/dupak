package com.virtualbox.torchick.rog;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;
import com.tbuonomo.viewpagerdotsindicator.WormDotsIndicator;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.adapter.RecycleAdapterIndicatorStrategis;
import com.virtualbox.torchick.rog.fragment.SubFragmentRoot;
import com.virtualbox.torchick.rog.gravitysnaphelper.GravitySnapHelper;
import com.virtualbox.torchick.rog.instance.IndicatorStrategis;
import com.virtualbox.torchick.rog.snapbar.Adapter;
import com.virtualbox.torchick.rog.snapbar.App;
import com.virtualbox.torchick.rog.snapbar.Snap;
import com.virtualbox.torchick.rog.snapbar.SnapAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.provider.MediaStore.Images.ImageColumns.ORIENTATION;
import static com.android.volley.VolleyLog.TAG;

/**
 * Created by Yusfil Pulungan on 3/20/2018.
 */

public class Root extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private RecyclerView mRecyclerView;
    private boolean mHorizontal;
    private OnFragmentInteractionListener mListener;
    private int doAnimation = 1;
    private View view;
    private String Key;
    private Button noInternetButton;
    //private String url = "https://sultradata.com/siserav2_/indikator_strategis.php";
    private String url;
    private RecyclerView mList;
    private NetworkInfo info;

    private LinearLayoutManager linearLayoutManager;
    private DividerItemDecoration dividerItemDecoration;
    private List<IndicatorStrategis> indicatorList;
    private RecyclerView.Adapter adapter;

    ViewPager viewPager;

    CarouselView carouselView;
    ScrollView scrollView;
    int[] sampleImages = {R.drawable.a1, R.drawable.a2, R.drawable.a3};
    ImageListener imageListener = new ImageListener() {
        @Override
        public void setImageForPosition(int position, ImageView imageView) {
            imageView.setImageResource(sampleImages[position]);
            imageView.setScaleType(ImageView.ScaleType.FIT_START);
        }
    };


    public Root() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        info = (NetworkInfo) ((ConnectivityManager)
                getContext().getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();

        if (info == null) {
            view = inflater.inflate(R.layout.no_internet_connection, container, false);
            noInternetButton = (Button) view.findViewById(R.id.no_internet_button);
            noInternetButton.setVisibility(View.GONE);
        } else {
            if (info.isConnected()) {
                view = inflater.inflate(R.layout.fragment_root, container, false);
//                mList = view.findViewById(R.id.main_list);
//
//                indicatorList = new ArrayList<>();
//                adapter = new RecycleAdapterIndicatorStrategis(getContext(), indicatorList);
//
//                linearLayoutManager = new LinearLayoutManager(getContext());
//                linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
//                dividerItemDecoration = new DividerItemDecoration(mList.getContext(), linearLayoutManager.getOrientation());
//
//                mList.setHasFixedSize(true);
//                mList.setLayoutManager(linearLayoutManager);
//                mList.addItemDecoration(dividerItemDecoration);
//                mList.setAdapter(adapter);
//                getData();

                //add viewpager
                SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(getChildFragmentManager());
                viewPager = view.findViewById(R.id.view_pager);
                viewPager.setAdapter(sectionsPagerAdapter);
                viewPager.setOffscreenPageLimit(4);

                WormDotsIndicator wormDotsIndicator = (WormDotsIndicator) view.findViewById(R.id.worm_dots_indicator);
                wormDotsIndicator.setViewPager(viewPager);

            } else {
                view = inflater.inflate(R.layout.fragment_root, container, false);
                noInternetButton = (Button) view.findViewById(R.id.no_internet_button);
                noInternetButton.setVisibility(View.GONE);
            }

        }

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        info = (NetworkInfo) ((ConnectivityManager)
                getContext().getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (info == null) {
        } else {
            if (info.isConnected()) {
                carouselView = (CarouselView) view.findViewById(R.id.carouselView);

                carouselView.setImageListener(imageListener);
                carouselView.setPageCount(sampleImages.length);

                mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
                mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                mRecyclerView.setHasFixedSize(true);

                //add parallax effect to carousel view
                scrollView = view.findViewById(R.id.scrollview);
                scrollView.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
                    @Override
                    public void onScrollChanged() {
//                        System.out.println(scrollView.getScrollY());
                        /* get the maximum height which we have scroll before performing any action */
                        int maxDistance = carouselView.getHeight();
                        /* how much we have scrolled */
                        int movement = scrollView.getScrollY();
                        /* calculate alpha */
                        float alphaFactor = 1-((movement * 1.0f) / (maxDistance - 1));

                        if (movement >= 0 && movement <= maxDistance) {
                            /*for image parallax with scroll */
                            carouselView.setTranslationY(-movement/2);
                            carouselView.setAlpha(alphaFactor);
//                            System.out.println(alphaFactor);
                        }
                    }
                });

                //get linearlayout height and screen height
                final LinearLayout layout = (LinearLayout) view.findViewById(R.id.linearlayout);
                final ImageView filler2 = view.findViewById(R.id.filler2);

                ViewTreeObserver vto = layout.getViewTreeObserver();
                vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                            layout.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                        } else {
                            layout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        }
                        int width  = layout.getMeasuredWidth();
                        int height = layout.getMeasuredHeight();
//                        System.out.println("linear layout height : "+pxToDp(height));

                        DisplayMetrics displayMetrics = new DisplayMetrics();
                        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                        int height_wm = displayMetrics.heightPixels;
                        int width_wm = displayMetrics.widthPixels;
//                        System.out.println("height_wm : "+pxToDp(height_wm));

                        int filler2_height = pxToDp(height_wm)+166-pxToDp(height);
//                        int filler2_height = pxToDp(height_wm)+166-pxToDp(height);
//                        filler2.setMinimumHeight(dpToPx(filler2_height));

                        viewPager.getLayoutParams().height = viewPager.getLayoutParams().height+ dpToPx(filler2_height);


                    }
                });



                if (savedInstanceState == null) {
                    mHorizontal = true;
                } else {
                    mHorizontal = savedInstanceState.getBoolean(ORIENTATION);
                }

                setupAdapter();
            }


        }
    }

    public static int dpToPx(int dp)
    {
        return (int) (dp * Resources.getSystem().getDisplayMetrics().density);
    }

    public static int pxToDp(int px)
    {
        return (int) (px / Resources.getSystem().getDisplayMetrics().density);
    }

    private void setupAdapter() {
        List<App> apps = getApps();

        SnapAdapter snapAdapter = new SnapAdapter();

            //snapAdapter.addSnap(new Snap(Gravity.CENTER_HORIZONTAL, "Snap center", apps));
            snapAdapter.addSnap(new Snap(Gravity.START, "", apps));
            //snapAdapter.addSnap(new Snap(Gravity.END, "Snap end", apps));
            //snapAdapter.addSnap(new Snap(Gravity.CENTER, "GravityPager snap", apps));
            mRecyclerView.setAdapter(snapAdapter);

    }

    public SnapAdapter getSnapAdapter(){
        return (SnapAdapter) mRecyclerView.getAdapter();
    }
    public RecyclerView getRecyclerView(){
        return mRecyclerView;
    }

    private List<App> getApps() {
        List<App> apps = new ArrayList<>();
        apps.add(new App("BRS", R.drawable.ic_brs));
        apps.add(new App("Publikasi", R.drawable.ic_publikasi));
        apps.add(new App("Tabel Statis", R.drawable.ic_statis));
        apps.add(new App("Tabel Dinamis", R.drawable.ic_dinamis));
        apps.add(new App("Tabel Generator", R.drawable.ic_dinamis));
        apps.add(new App("Indikator Strategis", R.drawable.ic_datastrategis));
        apps.add(new App("Berita", R.drawable.ic_berita));
        apps.add(new App("Infografis", R.drawable.ic_infografis));
        return apps;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState != null) {
            // Do Nothing
            doAnimation = savedInstanceState.getInt("doAnimation", 0);
            Log.d("doAnimation", String.valueOf(doAnimation));
        }else{

        }

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("doAnimation", 0);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    private void getData() {
        final ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        Key = ((MainActivity) getActivity()).getKey();
        url = "https://webapi.bps.go.id/v1/api/list/?model=indicators&domain=7400&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                JSONObject alldata = new JSONObject(response);
                JSONArray data = alldata.getJSONArray("data");
                JSONArray indikatorStrategis = data.getJSONArray(1);

                            for (int i = 0; i < indikatorStrategis.length(); i++) {
                                try {

                                    JSONObject jsonObject = indikatorStrategis.getJSONObject(i);

                                    IndicatorStrategis indicatorStrategis = new IndicatorStrategis();
//                                    indicatorStrategis.setId(jsonObject.getInt("id"));
                                    if(jsonObject.getString("unit").equals("Tidak Ada Satuan")){
                                        indicatorStrategis.setJudul(jsonObject.getString("title"));
                                    }else{
                                        indicatorStrategis.setJudul(jsonObject.getString("title")+" ("+jsonObject.getString("unit")+")");
                                    }

                                    indicatorStrategis.setNilai((float) jsonObject.getDouble("value"));

                                    indicatorList.add(indicatorStrategis);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    progressDialog.dismiss();
                                }
                            }
                            adapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                        } catch (JSONException e) {
                            e.printStackTrace();
                            progressDialog.dismiss();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        PubSingleton.getmInstance(getContext()).addToRequestQueue(stringRequest);
    }

    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            return SubFragmentRoot.newInstance(position+1, "");
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 4;
        }
    }

}
