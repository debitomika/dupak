package com.virtualbox.torchick.rog.instance;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ImageWebApi implements Serializable {
    @SerializedName("inf_id")
    private String inf_id;
    @SerializedName("title")
    private String title;
    @SerializedName("img")
    private String img;
    @SerializedName("desc")
    private String desc;
    @SerializedName("category")
    private String category;
    @SerializedName("dl")
    private String dl;

    public ImageWebApi() {
    }

    public ImageWebApi(String inf_id, String title, String img, String desc, String category, String dl) {
        this.inf_id = inf_id;
        this.title = title;
        this.img = img;
        this.desc = desc;
        this.category = category;
        this.dl = dl;
    }

    @Override
    public String toString() {
        return this.title;
    }

    public String getInf_id() {
        return inf_id;
    }

    public void setInf_id(String inf_id) {
        this.inf_id = inf_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDl() {
        return dl;
    }

    public void setDl(String dl) {
        this.dl = dl;
    }
}
