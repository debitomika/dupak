package com.virtualbox.torchick.rog.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.instance.IndikatorStrategis;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class RecycleAdapterIndikatorStrategis extends RecyclerView.Adapter<RecycleAdapterIndikatorStrategis.IndikatorStrategisViewHolder> {

    private List<IndikatorStrategis> indikatorStrategisList = new ArrayList<>();
    private Context mContext;
    View view;
    String satker;

    public RecycleAdapterIndikatorStrategis(List<IndikatorStrategis> indikatorStrategisList, Context context, String satker){

       this.indikatorStrategisList = indikatorStrategisList;
        this.mContext = context;
        this.satker =satker;
    }


    @Override
    public IndikatorStrategisViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_indikatorstrategis_item,parent,false);

        return new IndikatorStrategisViewHolder(view);
    }

    public static String geTkey1(){
        return "5FE882F5E894E5D3070B7607285260220";
    }

    @Override
    public void onBindViewHolder(IndikatorStrategisViewHolder holder, int position) {
        if(indikatorStrategisList.get(position).getUnit().equals("Tidak Ada Satuan")){
            holder.title.setText(indikatorStrategisList.get(position).getTitle());
        }else{
            holder.title.setText(indikatorStrategisList.get(position).getTitle()+" ("+indikatorStrategisList.get(position).getUnit()+")");
        }
        holder.value.setText(indikatorStrategisList.get(position).getValue());
        holder.sumber.setText("Sumber : "+ indikatorStrategisList.get(position).getData_source());

//        Picasso.with(mContext)
//                .load(indikatorStrategisList.get(position).getCover())
//                .placeholder(R.drawable.load)
//                .error(R.drawable.bps)
//                .into(holder.imageView);

        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                CharSequence text = ""+p;
//                int duration = Toast.LENGTH_SHORT;
//
//                Toast toast = Toast.makeText(mContext, text, duration);
//                toast.show();
            }
        });
    }



    @Override
    public int getItemCount() {
        return indikatorStrategisList.size();
    }

    public static class IndikatorStrategisViewHolder extends  RecyclerView.ViewHolder{

        TextView title, value, sumber;
        ImageView imageView;
        // FloatingActionButton floatingActionButton;

        public IndikatorStrategisViewHolder(View itemView) {
            super(itemView);

            title = (TextView)itemView.findViewById(R.id.title);
            value = (TextView)itemView.findViewById(R.id.value);
            sumber = (TextView)itemView.findViewById(R.id.sumber);
            // floatingActionButton = (FloatingActionButton)itemView.findViewById(R.id.buttonDowmnload);

        }
    }
}
