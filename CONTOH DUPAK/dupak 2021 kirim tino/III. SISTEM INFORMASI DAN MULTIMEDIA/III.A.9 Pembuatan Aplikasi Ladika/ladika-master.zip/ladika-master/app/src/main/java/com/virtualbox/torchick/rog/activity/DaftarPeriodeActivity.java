package com.virtualbox.torchick.rog.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.SparseBooleanArray;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.instance.Deskripsi;
import com.virtualbox.torchick.rog.instance.Periode;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DaftarPeriodeActivity extends AppCompatActivity {
    private String Satker, Key;
    private String Id_var, Id_turvar, Judul_tabel, Notes;
    private ImageView imageView;
    private String periodeParam="";
    private List<Periode> periodeListAll = new ArrayList<>();
    ListView periodeListView;
    private CheckBox select_all;
    private Button btn_next;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        Intent intent=getIntent();
        this.Id_var = intent.getStringExtra("id_variabel");
        this.Id_turvar = intent.getStringExtra("id_turvar");
        this.Judul_tabel = intent.getStringExtra("judul_tabel");
        this.Notes = intent.getStringExtra("notes");
        ActionBar ab = getSupportActionBar();
        ab.setDisplayShowHomeEnabled(true);
        ab.setDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.periodeactivity_main);
        setTitle("Periode Waktu");

        btn_next = (Button) findViewById(R.id.btn_next);
        btn_next.setVisibility(View.GONE);
        periodeListView = (ListView) findViewById(R.id.listPeriode);
        imageView = (ImageView) findViewById(R.id.imageViewLoading);
        Glide.with(DaftarPeriodeActivity.this)
                .load(R.drawable.load)
                .into(imageView);
        select_all = (CheckBox) findViewById(R.id.checkall);
        select_all.setVisibility(View.GONE);
        select_all.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(select_all.isChecked())
                {
                    for ( int i=0; i < periodeListView.getCount(); i++) {
                        periodeListView.setItemChecked(i, true);
                    }
                }
                if(!select_all.isChecked())
                {
                    for ( int i=0; i < periodeListView.getCount(); i++) {
                        periodeListView.setItemChecked(i, false);
                    }
                }

            }
        });
        getPeriode();
    }

    private void getPeriode() {

        Satker = MainActivity.SATKER;
        Key = MainActivity.KEY;

        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=th&var="+this.Id_var+"&domain="+Satker+"&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject alldata = new JSONObject(response);
                            String des = alldata.getString("data");
                            TextView size = findViewById(R.id.size);
                            LinearLayout periodeLinierLayout=findViewById(R.id.periodeLinierLayout);
                            if(des.matches("")) {
                                periodeLinierLayout.setGravity(Gravity.CENTER);
                                periodeListView.setVisibility(View.GONE);
                                select_all.setVisibility(View.GONE);
                                size.setText("Tidak memiliki periode");
                            }else {
                                size.setVisibility(View.GONE);
                                periodeLinierLayout.setGravity(Gravity.TOP);
                                JSONArray data = alldata.getJSONArray("data");
                                JSONObject deskripsi = data.getJSONObject(0);

                                GsonBuilder builder = new GsonBuilder();
                                Gson gson = builder.create();

                                Deskripsi desc = gson.fromJson(deskripsi.toString(), Deskripsi.class);
                                for (int i = 1; i <= Integer.valueOf(desc.getPages()); i++) {
                                    getDaftarPeriodeByPage(String.valueOf(i));
                                }

                                select_all.setVisibility(View.VISIBLE);
                            }
                            imageView.setVisibility(View.GONE);
                            btn_next.setVisibility(View.VISIBLE);
                        } catch (JSONException e) {
                            Toast.makeText(DaftarPeriodeActivity.this,"error",Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        PubSingleton.getmInstance(DaftarPeriodeActivity.this).addToRequestQueue(stringRequest);
    }

    private void getDaftarPeriodeByPage(final String page) {

        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=th&var="+this.Id_var+"&page="+page+"&domain="+Satker+"&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");
                            JSONArray periode = data.getJSONArray(1);
                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();
                            List<Periode> periodeList = Arrays.asList(gson.fromJson(periode.toString(),Periode[].class));
                            periodeListAll.addAll(periodeList);
                            List<String> periodeString = new ArrayList<String>();
                            for(int i=0; i<periodeListAll.size(); i++){
                                periodeString.add(periodeListAll.get(i).getTh());
                            }
                            periodeListView.setChoiceMode(periodeListView.CHOICE_MODE_MULTIPLE);
                            periodeListView.setTextFilterEnabled(true);

                            ArrayAdapter<String> adapter = new ArrayAdapter<String>
                                    (DaftarPeriodeActivity.this,
                                            android.R.layout.simple_list_item_multiple_choice,
                                            android.R.id.text1, periodeString);
                            
                            //add sort descending
                            adapter.sort(new Comparator<String>() {
                                @Override
                                public int compare(String lhs, String rhs) {
                                    return rhs.compareTo(lhs);   //sort descending
                                }
                            });

                            periodeListView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        PubSingleton.getmInstance(DaftarPeriodeActivity.this).addToRequestQueue(stringRequest);


    }

    public void goVerticalVariabel(View v){
        if(!periodeListAll.isEmpty()) {
            String param = "";
            for (int i = 0; i < periodeListAll.size(); i++) {
                if (periodeListView.isItemChecked(i)) {
                    param += ";" + periodeListAll.get(i).getTh_id();
                }
            }
            if (param.isEmpty()) {
                periodeParam = "";
            } else {
                periodeParam = param.substring(1);
            }
        }

        Intent intent = new Intent(v.getContext(), DaftarTurunanPeriodeActivity.class);
        intent.putExtra("id_variabel", this.Id_var);
        intent.putExtra("id_turvar", this.Id_turvar);
        intent.putExtra("id_periode", this.periodeParam);
        intent.putExtra("judul_tabel", this.Judul_tabel);
        intent.putExtra("notes", this.Notes);
        v.getContext().startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {
            this.finish();
        } else {
            super.onBackPressed(); //replaced
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}

