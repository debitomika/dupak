package com.virtualbox.torchick.rog.instance;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class Periode {

    @SerializedName("th_id")
    private String th_id;
    @SerializedName("th")
    private String th;

    public String getTh_id() {
        return th_id;
    }

    public void setTh_id(String th_id) {
        this.th_id = th_id;
    }

    public String getTh() {
        return th;
    }

    public void setTh(String th) {
        this.th = th;
    }
}
