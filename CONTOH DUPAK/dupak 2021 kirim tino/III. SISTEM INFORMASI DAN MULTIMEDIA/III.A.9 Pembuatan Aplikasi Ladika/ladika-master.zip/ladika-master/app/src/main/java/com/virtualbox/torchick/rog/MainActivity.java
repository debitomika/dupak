package com.virtualbox.torchick.rog;

import android.app.ActivityManager;
import android.app.SearchManager;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;

import com.virtualbox.torchick.rog.activity.AboutActivity;
import com.virtualbox.torchick.rog.activity.DetailBrsActivity;
import com.virtualbox.torchick.rog.fragment.FragmentBerita;
import com.virtualbox.torchick.rog.fragment.FragmentBrs;
import com.virtualbox.torchick.rog.fragment.FragmentIndikatorStrategis;
import com.virtualbox.torchick.rog.fragment.FragmentInfografis;
import com.virtualbox.torchick.rog.fragment.FragmentListTabelDinamis;
import com.virtualbox.torchick.rog.fragment.FragmentPublikasi;
import com.virtualbox.torchick.rog.fragment.FragmentTabelDinamis;
import com.virtualbox.torchick.rog.fragment.FragmentTabelStatis;
import com.virtualbox.torchick.rog.fragment.FragmentTentangSultra;
import com.virtualbox.torchick.rog.helper.DBHelper;

import java.util.List;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    DBHelper DBHelper;
    SQLiteDatabase sqLiteDatabase;
    Cursor cursor;
    List<String> mAllValues;
    Toolbar toolbar;
    DrawerLayout drawer;
    NavigationView navigationView;
    FragmentManager fragmentManager;
    Fragment fragment = null;
    private String Satker;
    private String Key;
    public static String PACKAGE_NAME, SATKER, KEY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        PACKAGE_NAME = getApplicationContext().getPackageName();
        DBHelper = new DBHelper(this);
        getConfig();
        SATKER = Satker;
        KEY = Key;

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);
        if (savedInstanceState == null) {
            fragment = new Root();
            callFragment(fragment);
        }

        setSatker(Satker);
        setKey(Key);
    }

    @Override
    public void onBackPressed() {

        int count = getFragmentManager().getBackStackEntryCount();

        if (count == 0) {
            super.onBackPressed();
            //additional code
        } else {
            getFragmentManager().popBackStack();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        // Add search menu
        final MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchManager searchManager = (SearchManager) MainActivity.this.getSystemService(this.SEARCH_SERVICE);
        SearchView searchView = null;
        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
        }
        if (searchView != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(MainActivity.this.getComponentName()));
        }
        final SearchView sv = searchView;

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {

                Fragment f = getSupportFragmentManager().findFragmentById(R.id.frame_container);
                if(f instanceof FragmentBrs){
                    // do something with f
                    ((FragmentBrs) f).search(s);
                }

                if(f instanceof FragmentPublikasi){
                    // do something with f
                    ((FragmentPublikasi) f).search(s);
                }

                if(!(f instanceof FragmentPublikasi)&&!(f instanceof FragmentBrs)){
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Warning")
                            .setMessage("Search hanya bisa dilakukan di menu BRS dan Publikasi")
//                            .setMessage(getPdf())
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    // continue with delete
                                }
                            })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                }

                if(!sv.isIconified()) {
                    sv.setIconified(true);
                }
                searchItem.collapseActionView();

                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
//                return true;
            }
        });



        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);
        }else if(id == R.id.action_clear){
            sqLiteDatabase = DBHelper.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("email", "");
            contentValues.put("password", "");
            sqLiteDatabase.update("auth", contentValues, "id = ?", new String[] { "1" });
            Snackbar.make(drawer, "Data login telah dihapus...", Snackbar.LENGTH_LONG).show();
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if(id == R.id.nav_wilayah){
            LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            final View formsView = inflater.inflate(R.layout.pilih_wilayah, null, false);
            final Spinner spinner1 = (Spinner) formsView.findViewById(R.id.spinner1);
            new AlertDialog.Builder(this)
                    .setView(formsView)
                    .setTitle("PILIH WILAYAH")
                    .setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(
                                        DialogInterface dialog, int id) {
                                    ContentValues cv = new ContentValues();
                                    DBHelper = new DBHelper(getBaseContext());
                                    sqLiteDatabase = DBHelper.getWritableDatabase();
                                    if(spinner1.getSelectedItemPosition()==0){
                                        cv.put("wilayah","7400");
                                    }else if(spinner1.getSelectedItemPosition()==1){
                                        cv.put("wilayah","7401");
                                    }else if(spinner1.getSelectedItemPosition()==2){
                                        cv.put("wilayah","7402");
                                    }else if(spinner1.getSelectedItemPosition()==3){
                                        cv.put("wilayah","7403");
                                    }else if(spinner1.getSelectedItemPosition()==4){
                                        cv.put("wilayah","7404");
                                    }else if(spinner1.getSelectedItemPosition()==5){
                                        cv.put("wilayah","7405");
                                    }else if(spinner1.getSelectedItemPosition()==6){
                                        cv.put("wilayah","7406");
                                    }else if(spinner1.getSelectedItemPosition()==7){
                                        cv.put("wilayah","7407");
                                    }else if(spinner1.getSelectedItemPosition()==8){
                                        cv.put("wilayah","7408");
                                    }else if(spinner1.getSelectedItemPosition()==9){
                                        cv.put("wilayah","7409");
                                    }else if(spinner1.getSelectedItemPosition()==10){
                                        cv.put("wilayah","7410");
                                    }else if(spinner1.getSelectedItemPosition()==11){
                                        cv.put("wilayah","7411");
                                    }else if(spinner1.getSelectedItemPosition()==12){
                                        cv.put("wilayah","7471");
                                    }else if(spinner1.getSelectedItemPosition()==13){
                                        cv.put("wilayah","7472");
                                    }
                                    sqLiteDatabase.update("config", cv,"id='1'", null);
                                    getConfig();
                                    SATKER = Satker;
                                    KEY = Key;
                                    dialog.cancel();
                                }
                            }).show();
        }else if (id == R.id.nav_beranda) {
            fragment = new Root();
            fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction()
                    .replace(R.id.frame_container, fragment, null)
                    .commit();
            setTitle("Beranda");
        } else if (id == R.id.nav_berita) {
            fragment = new FragmentBerita();
            callFragment(fragment);
            //fragment.refreshSatker();
            setTitle("Berita");
        } else if (id == R.id.nav_brs) {
            fragment = new FragmentBrs();
            callFragment(fragment);
            setTitle("BRS");
        } else if (id == R.id.nav_publikasi){
            fragment = new FragmentPublikasi();
            callFragment(fragment);
            setTitle("Publikasi");
        } else if (id == R.id.nav_tabelstatis){
            fragment = new FragmentTabelStatis();
            callFragment(fragment);
            setTitle("Tabel Statis");
        } else if (id == R.id.nav_tabeldinamis){
//            fragment = new FragmentTabelDinamis();
            fragment = new FragmentListTabelDinamis();
            callFragment(fragment);
            setTitle("Tabel Dinamis");
        }else if (id == R.id.nav_tabelgenerator){
            fragment = new FragmentTabelDinamis();
            callFragment(fragment);
            setTitle("Tabel Dinamis");
        }else if(id== R.id.nav_indikatorstrategis){
            fragment = new FragmentIndikatorStrategis();
            callFragment(fragment);
            setTitle("Indikator Strategis");
        }else if (id == R.id.nav_infografis){
            fragment = new FragmentInfografis();
            callFragment(fragment);
            setTitle("Infografis");
        }else if(id== R.id.nav_info){
            fragment = new FragmentTentangSultra();
            callFragment(fragment);
            setTitle("Tentang Sulawesi Tenggara");
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void callFragment(Fragment fragment) {
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.frame_container, fragment, null)
                .addToBackStack(null)
                .commit();
    }

    public String getSatker() {
        return Satker;
    }

    public void setSatker(String satker) {
        Satker = satker;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }

    private void getConfig(){
        sqLiteDatabase = DBHelper.getWritableDatabase();
        cursor = sqLiteDatabase.rawQuery("SELECT * FROM config", null);
        cursor.moveToFirst();
        do {
            this.Satker =  cursor.getString(2);
            this.Key =  cursor.getString(1);
        } while (cursor.moveToNext());
    }

    public NavigationView getNavigationView(){
        return navigationView;
    }

}
