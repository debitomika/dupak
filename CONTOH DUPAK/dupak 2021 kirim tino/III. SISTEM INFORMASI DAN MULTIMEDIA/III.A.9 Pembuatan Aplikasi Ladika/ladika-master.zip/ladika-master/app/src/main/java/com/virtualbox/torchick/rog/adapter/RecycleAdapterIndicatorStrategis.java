package com.virtualbox.torchick.rog.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.instance.IndicatorStrategis;

import java.util.List;

public class RecycleAdapterIndicatorStrategis extends RecyclerView.Adapter<RecycleAdapterIndicatorStrategis.ViewHolder> {

    private Context context;
    private List<IndicatorStrategis> list;
    boolean isVisible = true;

    public RecycleAdapterIndicatorStrategis(Context context, List<IndicatorStrategis> list) {
        this.context = context;
        this.list = list;
    }

    public void setVisible(boolean isVisible){
        this.isVisible = isVisible;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.indicator_strategis, parent, false);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "Silahkan klik menu di atas untuk melihat tampilan rinci", Toast.LENGTH_SHORT).show();
            }
        });
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        IndicatorStrategis indicatorStrategis = list.get(position);

        holder.textId.setText(String.valueOf(indicatorStrategis.getId()));
        holder.textJudul.setText(String.valueOf(indicatorStrategis.getJudul()));
//        holder.textNilai.setText(String.valueOf(indicatorStrategis.getNilai()));
        String roundoff = String.format("%.2f", Double.valueOf(indicatorStrategis.getNilai()));
        holder.textNilai.setText(roundoff);
        holder.textTanggal.setText(String.valueOf(indicatorStrategis.getTanggal()));

        if(!isVisible){
            //hide nilai for non indicator statistic
            holder.textNilai.setVisibility(View.GONE);
        }else{
            //hide tanggal for indicator statistic
            holder.textTanggal.setVisibility(View.GONE);
        }

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textId, textJudul, textNilai, textTanggal;

        public ViewHolder(View itemView) {
            super(itemView);

            textId = itemView.findViewById(R.id.main_id);
            textJudul = itemView.findViewById(R.id.main_judul);
            textNilai = itemView.findViewById(R.id.main_nilai);
            textTanggal = itemView.findViewById(R.id.tanggal_rilis);

        }
    }

}