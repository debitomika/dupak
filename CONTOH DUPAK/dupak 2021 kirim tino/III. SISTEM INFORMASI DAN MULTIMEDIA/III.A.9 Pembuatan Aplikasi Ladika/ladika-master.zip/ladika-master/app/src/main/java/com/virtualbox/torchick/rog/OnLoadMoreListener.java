package com.virtualbox.torchick.rog;

public interface OnLoadMoreListener {
    void onLoadMore();
}