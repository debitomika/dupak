package com.virtualbox.torchick.rog.activity;

import android.Manifest;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.download.ProfileActivity;
import com.virtualbox.torchick.rog.instance.Detail.DetailBrs;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DetailBrsActivity extends AppCompatActivity {
    private String Satker, Key;
    private String Id_brs;
    private ImageView imageView;
    private ImageView imageViewDl;
    private Button downloadButton;

    private String pdf;
    private String idpdf;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        haveStoragePermission();

        Intent intent=getIntent();
        this.Id_brs = intent.getStringExtra("id_brs");
        ActionBar ab = getSupportActionBar();
        ab.setDisplayShowHomeEnabled(true);
        ab.setDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.detailbrsactivity_main);
        setTitle("Detail BRS");
        imageView = (ImageView) findViewById(R.id.imageViewLoading);
        imageViewDl = (ImageView) findViewById(R.id.downloading);
        downloadButton = (Button) findViewById(R.id.button_download);

        Glide.with(DetailBrsActivity.this)
                .load(R.drawable.load)
                .into(imageView);
        getDetailBrs();

        imageViewDl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(DetailBrsActivity.this, ProfileActivity.class);
                i.putExtra("pdfurl", getPdf());
                i.putExtra("idpdf", getIdpdf());
                startActivity(i);

            }
        });

        downloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(haveStoragePermission()){
//                    downloadPdf();
                    new AlertDialog.Builder(DetailBrsActivity.this)
                            .setTitle("Download")
                            .setMessage("Apakah anda yakin akan melakukan download BRS?")
//                            .setMessage(getPdf())
                            .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    // continue with download
                                    downloadPdf();
                                    Toast.makeText(DetailBrsActivity.this, "Download sedang berjalan di background process, silahkan lihat progress download di notifikasi", Toast.LENGTH_LONG).show();
                                }
                            })
                            .setNegativeButton(android.R.string.cancel, null)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                    Log.d("download_brs", getPdf());
                }
            }
        });
    }

    private void getDetailBrs() {

        Satker = MainActivity.SATKER;
        Key = MainActivity.KEY;

        String server_url = "https://webapi.bps.go.id/v1/api/view/?model=pressrelease&id="+this.Id_brs+"&lang=ind&domain=" + Satker + "&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {
                            JSONObject alldata = new JSONObject(response);
                            JSONObject des = alldata.getJSONObject("data");
                            String stringdes = des.toString();

                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();
                            DetailBrs detailBrs = gson.fromJson(stringdes, DetailBrs.class);

                            setPdf(detailBrs.getPdf());
//                            setIdpdf("BPS-"+detailBrs.getTitle().substring(0,30).replace(" ","")+".pdf");
                            setIdpdf("BPS-"+detailBrs.getTitle().substring(0,30).replace(" ","-")+".pdf");

                            TextView tvName = findViewById(R.id.title_news);
                            TextView tanggal_rilis = findViewById(R.id.rl_date);
                            TextView size = findViewById(R.id.size);
                            tvName.setText(detailBrs.getTitle());
                            tanggal_rilis.setText("Diunggah tanggal : "+detailBrs.getRl_date());
                            size.setText(" ("+detailBrs.getSize()+")");
                            WebView wbName = findViewById(R.id.detail_news);
                            wbName.getSettings().setJavaScriptEnabled(true);
                            String html = "<html><body style='text-alignment:justify'>"+detailBrs.getAbstract()+"</body></html>";
                            String encodedHtml = Html.fromHtml(html).toString();
                            wbName.loadData(encodedHtml, "text/html", null);
                            imageView.setVisibility(View.GONE);
                        } catch (JSONException e) {
                            Toast.makeText(DetailBrsActivity.this,"error",Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        PubSingleton.getmInstance(DetailBrsActivity.this).addToRequestQueue(stringRequest);
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {
            this.finish();
        } else {
            super.onBackPressed(); //replaced
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public String getIdpdf() {
        return idpdf;
    }

    public void setIdpdf(String idpdf) {
        this.idpdf = idpdf;
    }
    public  boolean haveStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                Log.e("Permission error","You have permission");
                return true;
            } else {

                Log.e("Permission error","You have asked for permission");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
        }
        else { //you dont need to worry about these stuff below api level 23
            Log.e("Permission error","You already have the permission");
            return true;
        }
    }

    private void downloadPdf(){
        String url = getPdf();
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setDescription("BRS BPS");
        request.setTitle(getIdpdf());
        // in order for this if to run, you must use the android 3.2 to compile your app
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            request.allowScanningByMediaScanner();
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        }
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, getIdpdf());

        // get download service and enqueue file
        DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        manager.enqueue(request);
    }
}

