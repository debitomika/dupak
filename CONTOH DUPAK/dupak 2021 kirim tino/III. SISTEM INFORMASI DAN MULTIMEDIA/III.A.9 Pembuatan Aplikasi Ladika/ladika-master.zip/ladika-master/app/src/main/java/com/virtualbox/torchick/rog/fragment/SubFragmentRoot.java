package com.virtualbox.torchick.rog.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.Root;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.adapter.RecycleAdapterIndicatorStrategis;
import com.virtualbox.torchick.rog.instance.IndicatorStrategis;
import com.virtualbox.torchick.rog.snapbar.App;
import com.virtualbox.torchick.rog.snapbar.Snap;
import com.virtualbox.torchick.rog.snapbar.SnapAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SubFragmentRoot.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SubFragmentRoot#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SubFragmentRoot extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private int mParamDataTipe;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    //custom
    private LinearLayoutManager linearLayoutManager;
    private DividerItemDecoration dividerItemDecoration;
    private List<IndicatorStrategis> indicatorList;
    private RecycleAdapterIndicatorStrategis adapter;
    private RecyclerView recyclerView;
    private TextView judul;

    public static final int DATA_INDICATOR = 1;
    public static final int DATA_BRS = 2;
    public static final int DATA_DYNAMIC_TABLE = 3;
    public static final int DATA_PUBLIKASI = 4;


    public SubFragmentRoot() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SubFragmentRoot.
     */
    // TODO: Rename and change types and number of parameters
    public static SubFragmentRoot newInstance(int param1, String param2) {
        SubFragmentRoot fragment = new SubFragmentRoot();
        Bundle args = new Bundle();
        args.putInt(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParamDataTipe = getArguments().getInt(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_sub_fragment_root, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recyclerView);
        indicatorList = new ArrayList<>();
        adapter = new RecycleAdapterIndicatorStrategis(getContext(), indicatorList);

        linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), linearLayoutManager.getOrientation());

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.addItemDecoration(dividerItemDecoration);
        recyclerView.setAdapter(adapter);

        judul = view.findViewById(R.id.judul);

        getData(mParamDataTipe);
//        updateNavigationViewBadge(DATA_INDICATOR, 99);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    private void getData() {
        final ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        String Key = ((MainActivity) getActivity()).getKey();
        String url = "https://webapi.bps.go.id/v1/api/list/?model=indicators&domain=7400&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");
                            JSONArray indikatorStrategis = data.getJSONArray(1);

                            for (int i = 0; i < indikatorStrategis.length(); i++) {
                                try {

                                    JSONObject jsonObject = indikatorStrategis.getJSONObject(i);

                                    IndicatorStrategis indicatorStrategis = new IndicatorStrategis();
//                                    indicatorStrategis.setId(jsonObject.getInt("id"));
                                    if(jsonObject.getString("unit").equals("Tidak Ada Satuan")){
                                        indicatorStrategis.setJudul(jsonObject.getString("title"));
                                    }else{
                                        indicatorStrategis.setJudul(jsonObject.getString("title")+" ("+jsonObject.getString("unit")+")");
                                    }

                                    indicatorStrategis.setNilai((float) jsonObject.getDouble("value"));

                                    indicatorList.add(indicatorStrategis);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    progressDialog.dismiss();
                                }
                            }
                            adapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                        } catch (JSONException e) {
                            e.printStackTrace();
                            progressDialog.dismiss();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        PubSingleton.getmInstance(getContext()).addToRequestQueue(stringRequest);
    }

    private void getData(final int DATA_TIPE) {
        final ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        String Key = ((MainActivity) getActivity()).getKey();
//        String url = "https://webapi.bps.go.id/v1/api/list/?model=pressrelease&domain=7400&key="+Key;
        String url = "";
        switch (DATA_TIPE) {
            case DATA_INDICATOR:
                url = "https://webapi.bps.go.id/v1/api/list/?model=indicators&domain=7400&key="+Key;
                judul.setText("Indikator Strategis");
                adapter.setVisible(true); //set indikator value to visible
                adapter.notifyDataSetChanged();
                break;
            case DATA_BRS:
                url = "https://webapi.bps.go.id/v1/api/list/?model=pressrelease&domain=7400&key="+Key;
                adapter.setVisible(false); //set indikator value to gone
                adapter.notifyDataSetChanged();
                judul.setText("Data BRS");
                break;
            case DATA_DYNAMIC_TABLE:
                url = "https://webapi.bps.go.id/v1/api/list/?model=dynamictable&domain=7400&key="+Key;
                adapter.setVisible(false); //set indikator value to gone
                adapter.notifyDataSetChanged();
                judul.setText("Tabel Statistik");
                break;
            case DATA_PUBLIKASI:
                url = "https://webapi.bps.go.id/v1/api/list/?model=publication&domain=7400&key="+Key;
                adapter.setVisible(false); //set indikator value to gone
                adapter.notifyDataSetChanged();
                judul.setText("Data Publikasi");
                break;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");
                            JSONArray indikatorStrategis = data.getJSONArray(1);

                            for (int i = 0; i < indikatorStrategis.length(); i++) {
                                try {

                                    JSONObject jsonObject = indikatorStrategis.getJSONObject(i);

                                    IndicatorStrategis indicatorStrategis = new IndicatorStrategis();
                                    indicatorStrategis.setJudul(jsonObject.getString("title"));
                                    if(DATA_TIPE==DATA_INDICATOR){
                                        if(jsonObject.getString("unit").equals("Tidak Ada Satuan")){
                                            indicatorStrategis.setJudul(jsonObject.getString("title"));
                                        }else{
                                            indicatorStrategis.setJudul(jsonObject.getString("title")+" ("+jsonObject.getString("unit")+")");
                                        }
                                        indicatorStrategis.setNilai((float) jsonObject.getDouble("value"));
                                    }
                                    if(DATA_TIPE==DATA_BRS||DATA_TIPE==DATA_PUBLIKASI){
                                        indicatorStrategis.setTanggal("Tanggal Rilis : "+jsonObject.getString("rl_date"));
                                    }
                                    if(DATA_TIPE==DATA_DYNAMIC_TABLE){
                                        indicatorStrategis.setTanggal("Tanggal Rilis : "+jsonObject.getString("updt_date"));
                                    }


                                    indicatorList.add(indicatorStrategis);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    progressDialog.dismiss();
                                }
                            }
                            adapter.notifyDataSetChanged();
                            progressDialog.dismiss();
                            updateNavigationViewBadge(DATA_TIPE, getCurrentMonthCount(indicatorList));
//                            System.out.println("FRAGMENT "+mParamDataTipe+" :"+getCurrentMonthCount(indicatorList));
                        } catch (JSONException e) {
                            e.printStackTrace();
                            progressDialog.dismiss();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        PubSingleton.getmInstance(getContext()).addToRequestQueue(stringRequest);
    }

    private int getCurrentMonthCount(List<IndicatorStrategis> indicatorList){
        int count = 0;
        int year = Calendar.getInstance().get(Calendar.YEAR);
        int month = Calendar.getInstance().get(Calendar.MONTH)+1; //january = 0
        String yearmonth = "";
        if(month<10){
            yearmonth = year+"-0"+month;
        }else{
            yearmonth = year+"-"+month;
        }

        for(int i=0; i<indicatorList.size(); i++){
            IndicatorStrategis indicatorStrategis =  indicatorList.get(i);
            if(indicatorStrategis.getTanggal()!=null&&indicatorStrategis.getTanggal().contains(yearmonth)){
                count++;
            }
        }

        return count;
    }

    private void updateNavigationViewBadge(final int DATA_TIPE, int count){
        NavigationView navigationView = ((MainActivity) getActivity()).getNavigationView();
        TextView textView = new TextView(getContext());
        textView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        textView.setText("+"+String.valueOf(count));
        textView.setTextColor(Color.WHITE);
        textView.setGravity(Gravity.CENTER);
        textView.setBackgroundResource(R.drawable.red_circle_drawable);
        textView.setTypeface(null, Typeface.BOLD);

        SnapAdapter snapAdapter = ((Root) getParentFragment()).getSnapAdapter();
        RecyclerView mRecyclerView = ((Root) getParentFragment()).getRecyclerView();
        Snap snap = snapAdapter.getSnap();
        List<App> apps = snap.getApps();
        App app;
        SnapAdapter snapAdapter1;

        if(count>0){
            switch (DATA_TIPE) {
                case DATA_INDICATOR:
                    navigationView.getMenu().findItem(R.id.nav_indikatorstrategis).setActionView(textView);
                    app = apps.get(5);
                    app.setNotif(String.valueOf(count));
                    snapAdapter1 = new SnapAdapter();
                    snapAdapter1.addSnap(new Snap(Gravity.START, "", apps));
                    mRecyclerView.setAdapter(snapAdapter1);
                    break;
                case DATA_BRS:
                    navigationView.getMenu().findItem(R.id.nav_brs).setActionView(textView);
                    app = apps.get(0);
                    app.setNotif(String.valueOf(count));
                    snapAdapter1 = new SnapAdapter();
                    snapAdapter1.addSnap(new Snap(Gravity.START, "", apps));
                    mRecyclerView.setAdapter(snapAdapter1);
                    break;
                case DATA_DYNAMIC_TABLE:
                    navigationView.getMenu().findItem(R.id.nav_tabeldinamis).setActionView(textView);
                    app = apps.get(3);
                    app.setNotif(String.valueOf(count));
                    snapAdapter1 = new SnapAdapter();
                    snapAdapter1.addSnap(new Snap(Gravity.START, "", apps));
                    mRecyclerView.setAdapter(snapAdapter1);
                    break;
                case DATA_PUBLIKASI:
                    navigationView.getMenu().findItem(R.id.nav_publikasi).setActionView(textView);
                    app = apps.get(1);
                    app.setNotif(String.valueOf(count));
                    snapAdapter1 = new SnapAdapter();
                    snapAdapter1.addSnap(new Snap(Gravity.START, "", apps));
                    mRecyclerView.setAdapter(snapAdapter1);
                    break;
            }
        }

    }


}
