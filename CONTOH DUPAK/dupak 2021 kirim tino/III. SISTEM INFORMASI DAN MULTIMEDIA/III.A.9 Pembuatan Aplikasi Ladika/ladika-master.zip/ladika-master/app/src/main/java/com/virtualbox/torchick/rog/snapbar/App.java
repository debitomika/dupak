package com.virtualbox.torchick.rog.snapbar;


public class App {

    private int mDrawable;
    private String mName;
    private String notif;

    public App(String name, int drawable) {
        mName = name;
        mDrawable = drawable;
    }

    public int getDrawable() {
        return mDrawable;
    }

    public String getName() {
        return mName;
    }

    public void setNotif(String notif){
        this.notif = notif;
    }

    public String getNotif(){
        return notif;
    }
}

