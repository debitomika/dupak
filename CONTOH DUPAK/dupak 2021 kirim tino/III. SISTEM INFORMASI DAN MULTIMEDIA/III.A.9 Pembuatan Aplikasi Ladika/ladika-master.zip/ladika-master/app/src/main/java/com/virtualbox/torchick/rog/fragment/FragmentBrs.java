package com.virtualbox.torchick.rog.fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.virtualbox.torchick.rog.PaginationScrollListener;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.RecycleAdapterBrs;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.instance.Brs;
import com.virtualbox.torchick.rog.instance.Deskripsi;
import com.virtualbox.torchick.rog.MainActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static com.android.volley.VolleyLog.TAG;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class FragmentBrs extends Fragment {

    private RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    List<Brs> brsListAll = new ArrayList<>();
    ImageView imageView;
    private RecycleAdapterBrs brsRecycleAdapter;
    String Satker, Key;

    private int page;
    private int currentpage;

    int lastPos;


    private static final int PAGE_START = 1;
    private boolean isLoading = false;
    private boolean isLastPage = false;
    // limiting to 5 for this tutorial, since total pages in actual API is very large. Feel free to modify.
    private int TOTAL_PAGES = 5;
    private int currentPage = PAGE_START;

    SwipeRefreshLayout swipeRefreshLayout;
    String keyword = "";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_brs, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewList);
        imageView = (ImageView) view.findViewById(R.id.imageViewLoading);
        swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swiperefresh);

        Glide.with(getContext())
                .load(R.drawable.load)
                .into(imageView);

        linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        brsRecycleAdapter = new RecycleAdapterBrs(brsListAll, getContext(), Satker);
        recyclerView.addOnScrollListener(new PaginationScrollListener(linearLayoutManager) {
            @Override
            protected void loadMoreItems() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        if (getCurrentpage() < getPage()) {
                            setCurrentpage(getCurrentpage()+1);
                            loadNextPage(String.valueOf(getCurrentpage()));
                        }else{
//                            Toast.makeText(getActivity(), "Data sudah lengkap...",
//                                    Toast.LENGTH_SHORT).show();
                        }

                    }
                }, 1000);

            }

            @Override
            public int getTotalPageCount() {
                return TOTAL_PAGES;
            }

            @Override
            public boolean isLastPage() {
                return isLastPage;
            }

            @Override
            public boolean isLoading() {
                return isLoading;
            }
        });

        loadFirstPage();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                keyword = "";
                loadFirstPage();
            }
        });

        return view;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser) {

            if ((MainActivity) getActivity() != null) {
                // ((MainActivity) getActivity()).setListActionBar();
            }

        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getCurrentpage() {
        return currentpage;
    }

    public void setCurrentpage(int currentpage) {
        this.currentpage = currentpage;
    }

    private void loadFirstPage() {
        Log.d(TAG, "loadFirstPage: ");

        Satker = ((MainActivity) getActivity()).getSatker();
        Key = ((MainActivity) getActivity()).getKey();

        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=pressrelease&domain=" + Satker + "&key="+Key;
        if(!keyword.equalsIgnoreCase("")){
            server_url = server_url+"&keyword="+keyword;
            swipeRefreshLayout.setRefreshing(true);
        }
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {
                            System.out.println("csc1");

                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");
                            JSONObject des = data.getJSONObject(0);
                            String stringdes = des.toString();

                            JSONArray brs = data.getJSONArray(1);
                            String stringpub = brs.toString();

                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();

                            Deskripsi desc = gson.fromJson(stringdes, Deskripsi.class);
                            setPage(Integer.valueOf(desc.getPages()));

                            List<Brs> brsList = Arrays.asList(gson.fromJson(stringpub, Brs[].class));
                            brsListAll.clear();
                            brsListAll.addAll(brsList);
                            recyclerView.setAdapter(brsRecycleAdapter);
                            brsRecycleAdapter.notifyDataSetChanged();
                            setCurrentpage(1);
                            imageView.setVisibility(View.GONE);
                            swipeRefreshLayout.setRefreshing(false);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            swipeRefreshLayout.setRefreshing(false);
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                swipeRefreshLayout.setRefreshing(false);

            }
        });

        PubSingleton.getmInstance(getContext()).addToRequestQueue(stringRequest);

    }

    private void loadNextPage(final String page) {
        swipeRefreshLayout.setRefreshing(true);
        Log.d(TAG, "loadNextPage: " + currentPage);
        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=pressrelease&domain=" + Satker + "&page=" + page + "&key="+Key;
        if(!keyword.equalsIgnoreCase("")){
            server_url = server_url+"&keyword="+keyword;
        }
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");


                            JSONArray brs = data.getJSONArray(1);

                            String stringpub = brs.toString();

                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();

                            List<Brs> brsList = Arrays.asList(gson.fromJson(stringpub, Brs[].class));
                            brsListAll.addAll(brsList);
                            brsRecycleAdapter.notifyDataSetChanged();
                            imageView.setVisibility(View.GONE);
                            swipeRefreshLayout.setRefreshing(false);
                            Toast.makeText(getActivity(), "New BRS loaded", Toast.LENGTH_LONG).show();


                        } catch (JSONException e) {
                            e.printStackTrace();
                            swipeRefreshLayout.setRefreshing(false);
                            Toast.makeText(getActivity(), "No more BRS", Toast.LENGTH_LONG).show();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                swipeRefreshLayout.setRefreshing(false);
                Toast.makeText(getActivity(), "Error response", Toast.LENGTH_LONG).show();

            }
        });

        PubSingleton.getmInstance(getContext()).addToRequestQueue(stringRequest);
    }

    public void search(String keyword){
        this.keyword = keyword;
        loadFirstPage();
    }
}