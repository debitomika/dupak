package com.virtualbox.torchick.rog.instance;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class TurunanVariabel {

    @SerializedName("turvar_id")
    private String turvar_id;
    @SerializedName("turvar")
    private String turvar;
    @SerializedName("group_turvar_id")
    private String group_turvar_id;
    @SerializedName("name_group_turvar")
    private String name_group_turvar;

    public String getTurvar_id() {
        return turvar_id;
    }

    public void setTurvar_id(String turvar_id) {
        this.turvar_id = turvar_id;
    }

    public String getTurvar() {
        return turvar;
    }

    public void setTurvar(String turvar) {
        this.turvar = turvar;
    }

    public String getGroup_turvar_id() {
        return group_turvar_id;
    }

    public void setGroup_turvar_id(String group_turvar_id) {
        this.group_turvar_id = group_turvar_id;
    }

    public String getName_group_turvar() {
        return name_group_turvar;
    }

    public void setName_group_turvar(String name_group_turvar) {
        this.name_group_turvar = name_group_turvar;
    }
}
