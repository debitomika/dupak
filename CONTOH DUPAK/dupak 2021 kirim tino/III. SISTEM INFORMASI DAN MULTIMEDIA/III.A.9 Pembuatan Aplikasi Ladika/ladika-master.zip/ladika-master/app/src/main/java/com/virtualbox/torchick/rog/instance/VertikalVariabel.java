package com.virtualbox.torchick.rog.instance;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class VertikalVariabel {

    @SerializedName("kode_ver_id")
    private String kode_ver_id;
    @SerializedName("vervar")
    private String vervar;
    @SerializedName("item_ver_id")
    private String item_ver_id;
    @SerializedName("group_ver_id")
    private String group_ver_id;
    @SerializedName("name_group_ver_id")
    private String name_group_ver_id;

    public String getKode_ver_id() {
        return kode_ver_id;
    }

    public void setKode_ver_id(String kode_ver_id) {
        this.kode_ver_id = kode_ver_id;
    }

    public String getVervar() {
        return vervar;
    }

    public void setVervar(String vervar) {
        this.vervar = vervar;
    }

    public String getItem_ver_id() {
        return item_ver_id;
    }

    public void setItem_ver_id(String item_ver_id) {
        this.item_ver_id = item_ver_id;
    }

    public String getGroup_ver_id() {
        return group_ver_id;
    }

    public void setGroup_ver_id(String group_ver_id) {
        this.group_ver_id = group_ver_id;
    }

    public String getName_group_ver_id() {
        return name_group_ver_id;
    }

    public void setName_group_ver_id(String name_group_ver_id) {
        this.name_group_ver_id = name_group_ver_id;
    }
}
