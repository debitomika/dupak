package com.virtualbox.torchick.rog.instance.Detail;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DetailBrs {
    @SerializedName("brs_id")
    private String brs_id;
    @SerializedName("title")
    private String title;
    @SerializedName("abstract")
    private String abstracts;
    @SerializedName("rl_date")
    private String rl_date;
    @SerializedName("pdf")
    private String pdf;
    @SerializedName("size")
    private String size;

    public String getBrs_id() {
        return brs_id;
    }

    public void setBrs_id(String brs_id) {
        this.brs_id = brs_id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public String getAbstract() {
        return abstracts;
    }

    public void setAbstract(String abstracts) {
        this.abstracts = abstracts;
    }

    public String getRl_date() {
        return rl_date;
    }

    public void setRl_date(String rl_date) {
        this.rl_date = rl_date;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

}
