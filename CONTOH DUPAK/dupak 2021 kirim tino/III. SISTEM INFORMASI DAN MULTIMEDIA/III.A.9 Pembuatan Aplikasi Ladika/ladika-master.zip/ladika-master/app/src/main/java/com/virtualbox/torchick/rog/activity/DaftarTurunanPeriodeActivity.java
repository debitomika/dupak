package com.virtualbox.torchick.rog.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.instance.Deskripsi;
import com.virtualbox.torchick.rog.instance.TurunanPeriode;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DaftarTurunanPeriodeActivity extends AppCompatActivity {
    private String Satker, Key;
    private String Id_var, Id_turvar, Id_periode, Judul_tabel, Notes;
    private ImageView imageView;
    private String turunanPeriodeParam="";
    private List<TurunanPeriode> turunanPeriodeListAll = new ArrayList<>();
    ListView turunanPeriodeListView;
    private CheckBox select_all;
    private Button btn_next;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        Intent intent=getIntent();
        this.Id_var = intent.getStringExtra("id_variabel");
        this.Id_turvar = intent.getStringExtra("id_turvar");
        this.Id_periode = intent.getStringExtra("id_periode");
        this.Judul_tabel = intent.getStringExtra("judul_tabel");
        this.Notes = intent.getStringExtra("notes");
        ActionBar ab = getSupportActionBar();
        ab.setDisplayShowHomeEnabled(true);
        ab.setDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.turunanperiodeactivity_main);
        setTitle("Turunan Periode Waktu");

        btn_next = (Button) findViewById(R.id.btn_next);
        btn_next.setVisibility(View.GONE);
        turunanPeriodeListView = (ListView) findViewById(R.id.listTurunanPeriode);
        imageView = (ImageView) findViewById(R.id.imageViewLoading);
        Glide.with(DaftarTurunanPeriodeActivity.this)
                .load(R.drawable.load)
                .into(imageView);
        select_all = (CheckBox) findViewById(R.id.checkall);
        select_all.setVisibility(View.GONE);
        select_all.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(select_all.isChecked())
                {
                    for ( int i=0; i < turunanPeriodeListView.getCount(); i++) {
                        turunanPeriodeListView.setItemChecked(i, true);
                    }
                }
                if(!select_all.isChecked())
                {
                    for ( int i=0; i < turunanPeriodeListView.getCount(); i++) {
                        turunanPeriodeListView.setItemChecked(i, false);
                    }
                }

            }
        });
        getTurunanPeriode();
    }

    private void getTurunanPeriode() {

        Satker = MainActivity.SATKER;
        Key = MainActivity.KEY;

        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=turth&var="+this.Id_var+"&domain="+Satker+"&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");
                            JSONArray periode = data.getJSONArray(1);
                            JSONObject turth_id = periode.getJSONObject(0);
                            TextView size = findViewById(R.id.size);
                            LinearLayout turunanPeriodeLinierLayout=findViewById(R.id.turunanPeriodeLinierLayout);
                            if(turth_id.getInt("turth_id")==0) {
                                turunanPeriodeLinierLayout.setGravity(Gravity.CENTER);
                                turunanPeriodeListView.setVisibility(View.GONE);
                                select_all.setVisibility(View.GONE);
                                size.setText("Tidak memiliki turunan periode");
                            }else {
                                size.setVisibility(View.GONE);
                                turunanPeriodeLinierLayout.setGravity(Gravity.TOP);
                                JSONObject deskripsi = data.getJSONObject(0);

                                GsonBuilder builder = new GsonBuilder();
                                Gson gson = builder.create();

                                Deskripsi desc = gson.fromJson(deskripsi.toString(), Deskripsi.class);
                                for (int i = 1; i <= Integer.valueOf(desc.getPages()); i++) {
                                    getDaftarTurunanPeriodeByPage(String.valueOf(i));
                                }

                                select_all.setVisibility(View.VISIBLE);
                            }
                            imageView.setVisibility(View.GONE);
                            btn_next.setVisibility(View.VISIBLE);
                        } catch (JSONException e) {
                            Toast.makeText(DaftarTurunanPeriodeActivity.this,"error",Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        PubSingleton.getmInstance(DaftarTurunanPeriodeActivity.this).addToRequestQueue(stringRequest);
    }

    private void getDaftarTurunanPeriodeByPage(final String page) {

        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=turth&var="+this.Id_var+"&page="+page+"&domain="+Satker+"&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");
                            JSONArray periode = data.getJSONArray(1);
                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();
                            List<TurunanPeriode> periodeList = Arrays.asList(gson.fromJson(periode.toString(),TurunanPeriode[].class));
                            turunanPeriodeListAll.addAll(periodeList);
                            List<String> periodeString = new ArrayList<String>();
                            for(int i=0; i<turunanPeriodeListAll.size(); i++){
                                periodeString.add(turunanPeriodeListAll.get(i).getTurth());
                            }
                            turunanPeriodeListView.setChoiceMode(turunanPeriodeListView.CHOICE_MODE_MULTIPLE);
                            turunanPeriodeListView.setTextFilterEnabled(true);

                            ArrayAdapter<String> adapter = new ArrayAdapter<String>
                                    (DaftarTurunanPeriodeActivity.this,
                                            android.R.layout.simple_list_item_multiple_choice,
                                            android.R.id.text1, periodeString);

                            //add sort descending
                            adapter.sort(new Comparator<String>() {
                                @Override
                                public int compare(String lhs, String rhs) {
                                    return rhs.compareTo(lhs);   //sort descending
                                }
                            });

                            turunanPeriodeListView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        PubSingleton.getmInstance(DaftarTurunanPeriodeActivity.this).addToRequestQueue(stringRequest);


    }

    public void goVerticalVariabel(View v){
        if(!turunanPeriodeListAll.isEmpty()) {
            String param = "";
            for (int i = 0; i < turunanPeriodeListAll.size(); i++) {
                if (turunanPeriodeListView.isItemChecked(i)) {
                    param += ";" + turunanPeriodeListAll.get(i).getTurth_id();
                }
            }
            if (param.isEmpty()) {
                turunanPeriodeParam = "";
            } else {
                turunanPeriodeParam = param.substring(1);
            }
        }

        Intent intent = new Intent(v.getContext(), DaftarVertikalVariabelActivity.class);
        intent.putExtra("id_variabel", this.Id_var);
        intent.putExtra("id_turvar", this.Id_turvar);
        intent.putExtra("id_periode", this.Id_periode);
        intent.putExtra("id_turunanperiode", turunanPeriodeParam);
        intent.putExtra("judul_tabel", this.Judul_tabel);
        intent.putExtra("notes", this.Notes);
        v.getContext().startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {
            this.finish();
        } else {
            super.onBackPressed(); //replaced
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}

