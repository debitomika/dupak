package com.virtualbox.torchick.rog.instance;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DaftarVariabel {

    @SerializedName("var_id")
    private String var_id;
    @SerializedName("title")
    private String title;
    @SerializedName("sub_id")
    private String sub_id;
    @SerializedName("sub_name")
    private String sub_name;
    @SerializedName("def")
    private String def;
    @SerializedName("notes")
    private String notes;
    @SerializedName("vertical")
    private String vertical;
    @SerializedName("unit")
    private String unit;
    @SerializedName("graph_id")
    private String graph_id;
    @SerializedName("graph_name")
    private String graph_name;

    public String getVar_id() {
        return var_id;
    }

    public void setVar_id(String var_id) {
        this.var_id = var_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSub_id() {
        return sub_id;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public String getSub_name() {
        return sub_name;
    }

    public void setSub_name(String sub_name) {
        this.sub_name = sub_name;
    }

    public String getDef() {
        return def;
    }

    public void setDef(String def) {
        this.def = def;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getVertical() {
        return vertical;
    }

    public void setVertical(String vertical) {
        this.vertical = vertical;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getGraph_id() {
        return graph_id;
    }

    public void setGraph_id(String graph_id) {
        this.graph_id = graph_id;
    }

    public String getGraph_name() {
        return graph_name;
    }

    public void setGraph_name(String graph_name) {
        this.graph_name = graph_name;
    }
}
