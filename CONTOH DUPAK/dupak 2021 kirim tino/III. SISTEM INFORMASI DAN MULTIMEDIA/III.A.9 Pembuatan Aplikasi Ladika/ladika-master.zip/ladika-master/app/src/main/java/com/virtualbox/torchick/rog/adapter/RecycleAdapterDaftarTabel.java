package com.virtualbox.torchick.rog.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.activity.DetailTabelStatisActivity;
import com.virtualbox.torchick.rog.instance.DaftarTabel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class RecycleAdapterDaftarTabel extends RecyclerView.Adapter<RecycleAdapterDaftarTabel.DaftarTabelViewHolder> {

    private List<DaftarTabel> daftarTabelList = new ArrayList<>();
    private Context mContext;
    View view;
    String satker;

    public RecycleAdapterDaftarTabel(List<DaftarTabel> daftarTabelList, Context context, String satker){

        this.daftarTabelList = daftarTabelList;
        this.mContext = context;
        this.satker =satker;
    }


    @Override
    public DaftarTabelViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_daftartabel_item,parent,false);

        return new DaftarTabelViewHolder(view);
    }

    public static String geTkey1(){
        return "5FE882F5E894E5D3070B7607285260220";
    }

    @Override
    public void onBindViewHolder(DaftarTabelViewHolder holder, int position) {
        final String id_tabel = daftarTabelList.get(position).getTable_id();
        holder.rl_date.setText("Tanggal Unggah : "+ daftarTabelList.get(position).getUpdt_date());
        final CharSequence p = daftarTabelList.get(position).getTitle();
        holder.title.setText(p);

//        Picasso.with(mContext)
//                .load(daftarTabelList.get(position).getCover())
//                .placeholder(R.drawable.load)
//                .error(R.drawable.bps)
//                .into(holder.imageView);

        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DetailTabelStatisActivity.class);
                intent.putExtra("id_tabel", id_tabel);
                v.getContext().startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        return daftarTabelList.size();
    }

    public static class DaftarTabelViewHolder extends  RecyclerView.ViewHolder{

        TextView rl_date,title;
        ImageView imageView;
        // FloatingActionButton floatingActionButton;

        public DaftarTabelViewHolder(View itemView) {
            super(itemView);

            rl_date = (TextView)itemView.findViewById(R.id.rl_date);


            title = (TextView)itemView.findViewById(R.id.title);
            imageView = (ImageView) itemView.findViewById(R.id.imageViewPublikasi);
            // floatingActionButton = (FloatingActionButton)itemView.findViewById(R.id.buttonDowmnload);

        }
    }
}
