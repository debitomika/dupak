package com.virtualbox.torchick.rog.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.activity.DetailBrsActivity;
import com.virtualbox.torchick.rog.instance.Brs;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class RecycleAdapterBrs extends RecyclerView.Adapter<RecycleAdapterBrs.BrsViewHolder> {

    private List<Brs> brsList = new ArrayList<>();
    private Context mContext;
    View view;
    String satker;

    public RecycleAdapterBrs(List<Brs> brsList, Context context, String satker){

       this.brsList = brsList;
        this.mContext = context;
        this.satker =satker;
    }


    @Override
    public BrsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_brs_item,parent,false);

        return new BrsViewHolder(view);
    }

    public static String geTkey1(){
        return "5FE882F5E894E5D3070B7607285260220";
    }

    @Override
    public void onBindViewHolder(BrsViewHolder holder, int position) {
        holder.subject.setText(brsList.get(position).getSubj());
        holder.tanggal_rilis.setText("Tanggal Rilis : "+ brsList.get(position).getRl_date());
        final CharSequence p = brsList.get(position).getTitle();
        final CharSequence id_brs = brsList.get(position).getBrs_id();
        holder.title.setText(p);

//        Picasso.with(mContext)
//                .load(brsList.get(position).getCover())
//                .placeholder(R.drawable.load)
//                .error(R.drawable.bps)
//                .into(holder.imageView);

        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DetailBrsActivity.class);
                intent.putExtra("id_brs", id_brs);
                v.getContext().startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        return brsList.size();
    }

    public static class BrsViewHolder extends  RecyclerView.ViewHolder{

        TextView subject, tanggal_rilis,title;
        ImageView imageView;
        // FloatingActionButton floatingActionButton;

        public BrsViewHolder(View itemView) {
            super(itemView);

            subject = (TextView)itemView.findViewById(R.id.subject);
            tanggal_rilis = (TextView)itemView.findViewById(R.id.tanggal_rilis);


            title = (TextView)itemView.findViewById(R.id.title);
            //imageView = (ImageView) itemView.findViewById(R.id.imageViewPublikasi);
            // floatingActionButton = (FloatingActionButton)itemView.findViewById(R.id.buttonDowmnload);

        }
    }
}
