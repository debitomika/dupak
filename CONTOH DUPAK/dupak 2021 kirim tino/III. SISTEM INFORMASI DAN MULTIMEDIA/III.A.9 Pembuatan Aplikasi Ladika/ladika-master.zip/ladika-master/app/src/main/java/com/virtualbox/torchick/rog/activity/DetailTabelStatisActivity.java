package com.virtualbox.torchick.rog.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.download.ProfileActivity;
import com.virtualbox.torchick.rog.instance.Detail.DetailTabelStatis;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DetailTabelStatisActivity extends AppCompatActivity {
    private String Satker, Key;
    private String Id_tabel;
    private ImageView imageView;
    private ImageView imageViewDl;

    private String pdf;
    private String idpdf;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        haveStoragePermission();

        Intent intent=getIntent();
        this.Id_tabel = intent.getStringExtra("id_tabel");
        ActionBar ab = getSupportActionBar();
        ab.setDisplayShowHomeEnabled(true);
        ab.setDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.detailtabelstatisactivity_main);
        setTitle("Detail Tabel");
        imageView = (ImageView) findViewById(R.id.imageViewLoading);
        imageViewDl = (ImageView) findViewById(R.id.downloading);
        Glide.with(DetailTabelStatisActivity.this)
                .load(R.drawable.load)
                .into(imageView);
        getDetailTabel();
        imageViewDl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(DetailTabelStatisActivity.this, ProfileActivity.class);
                i.putExtra("pdfurl", getPdf());
                i.putExtra("idpdf", getIdpdf());
                startActivity(i);

            }
        });
    }

    private void getDetailTabel() {

        Satker = MainActivity.SATKER;
        Key = MainActivity.KEY;

        String server_url = "https://webapi.bps.go.id/v1/api/view/?model=statictable&id="+this.Id_tabel+"&lang=ind&domain=" + Satker + "&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {
                            JSONObject alldata = new JSONObject(response);
                            JSONObject des = alldata.getJSONObject("data");
                            String stringdes = des.toString();

                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();
                            DetailTabelStatis detailTabelStatis = gson.fromJson(stringdes, DetailTabelStatis.class);

                            setPdf(detailTabelStatis.getExcel());
                            setIdpdf("BPS-"+detailTabelStatis.getTitle().substring(0,30).replace(" ","")+".xls");

                            TextView tanggal_rilis = findViewById(R.id.rl_date);
                            TextView size = findViewById(R.id.size);
                            tanggal_rilis.setText("Tanggal Unggah : "+detailTabelStatis.getCr_date());
                            size.setText(" ("+detailTabelStatis.getSize()+")");
                            WebView wbName = findViewById(R.id.detail_news);
                            wbName.getSettings().setJavaScriptEnabled(true);
                            String html = "<html><body style='width:100%'>"+detailTabelStatis.getTable()+"</body></html>";
                            String encodedHtml = Html.fromHtml(html).toString();
                            wbName.loadData(encodedHtml, "text/html", null);
                            imageView.setVisibility(View.GONE);
                        } catch (JSONException e) {
                            Toast.makeText(DetailTabelStatisActivity.this,"error",Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        PubSingleton.getmInstance(DetailTabelStatisActivity.this).addToRequestQueue(stringRequest);
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {
            this.finish();
        } else {
            super.onBackPressed(); //replaced
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public String getIdpdf() {
        return idpdf;
    }

    public void setIdpdf(String idpdf) {
        this.idpdf = idpdf;
    }
    public  boolean haveStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                Log.e("Permission error","You have permission");
                return true;
            } else {

                Log.e("Permission error","You have asked for permission");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
        }
        else { //you dont need to worry about these stuff below api level 23
            Log.e("Permission error","You already have the permission");
            return true;
        }
    }

}

