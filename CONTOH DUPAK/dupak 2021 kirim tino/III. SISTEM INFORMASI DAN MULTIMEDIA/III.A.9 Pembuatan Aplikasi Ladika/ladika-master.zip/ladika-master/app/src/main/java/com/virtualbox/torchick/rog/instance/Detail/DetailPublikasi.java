package com.virtualbox.torchick.rog.instance.Detail;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DetailPublikasi {
    @SerializedName("pub_id")
    private String pub_id;
    @SerializedName("title")
    private String title;
    @SerializedName("kat_no")
    private String kat_no;
    @SerializedName("pub_no")
    private String pub_no;
    @SerializedName("issn")
    private String issn;
    @SerializedName("abstract")
    private String abstracts;
    @SerializedName("sch_date")
    private String sch_date;
    @SerializedName("rl_date")
    private String rl_date;
    @SerializedName("updt_date")
    private String updt_date;
    @SerializedName("cover")
    private String cover;
    @SerializedName("pdf")
    private String pdf;
    @SerializedName("size")
    private String size;

    public String getPub_id() {
        return pub_id;
    }

    public void setPub_id(String pub_id) {
        this.pub_id = pub_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getKat_no() {
        return kat_no;
    }

    public void setKat_no(String kat_no) {
        this.kat_no = kat_no;
    }

    public String getPub_no() {
        return pub_no;
    }

    public void setPub_no(String pub_no) {
        this.pub_no = pub_no;
    }

    public String getIssn() {
        return issn;
    }

    public void setIssn(String issn) {
        this.issn = issn;
    }

    public String getAbstracts() {
        return abstracts;
    }

    public void setAbstracts(String abstracts) {
        this.abstracts = abstracts;
    }

    public String getSch_date() {
        return sch_date;
    }

    public void setSch_date(String sch_date) {
        this.sch_date = sch_date;
    }

    public String getRl_date() {
        return rl_date;
    }

    public void setRl_date(String rl_date) {
        this.rl_date = rl_date;
    }

    public String getUpdt_date() {
        return updt_date;
    }

    public void setUpdt_date(String updt_date) {
        this.updt_date = updt_date;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }
}
