package com.virtualbox.torchick.rog.adapter;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.fragment.FragmentDaftarTabel;
import com.virtualbox.torchick.rog.instance.Subject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class RecycleAdapterSubject extends RecyclerView.Adapter<RecycleAdapterSubject.SubjectViewHolder> {

    private List<Subject> subjectList = new ArrayList<>();
    private Context mContext;
    View view;
    String satker;

    public RecycleAdapterSubject(List<Subject> subjectList, Context context, String satker){

       this.subjectList = subjectList;
        this.mContext = context;
        this.satker =satker;
    }


    @Override
    public SubjectViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_subject_item,parent,false);

        return new SubjectViewHolder(view);
    }

    public static String geTkey1(){
        return "5FE882F5E894E5D3070B7607285260220";
    }

    @Override
    public void onBindViewHolder(SubjectViewHolder holder, int position) {
        final CharSequence p = subjectList.get(position).getTitle();
        final String id_subj = subjectList.get(position).getSub_id();
        holder.title.setText(p);

//        Picasso.with(mContext)
//                .load(subjectList.get(position).getCover())
//                .placeholder(R.drawable.load)
//                .error(R.drawable.bps)
//                .into(holder.imageView);

        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentDaftarTabel fragmentDaftarTabel= new FragmentDaftarTabel();
                Bundle bundle=new Bundle();
                bundle.putString("title", p.toString());
                bundle.putString("id_sub", id_subj.toString());
                fragmentDaftarTabel.setArguments(bundle);

                String backStateName = fragmentDaftarTabel.getClass().getName();

                FragmentManager manager = ((FragmentActivity)mContext).getSupportFragmentManager();
                boolean fragmentPopped = manager.popBackStackImmediate (backStateName, 0);
                if (!fragmentPopped) {
                    FragmentManager fragmentManager = ((FragmentActivity) mContext).getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.frame_container, fragmentDaftarTabel, null)
                            .addToBackStack(null)
                            .commit();
                }
            }
        });
        }



    @Override
    public int getItemCount() {
        return subjectList.size();
    }

    public static class SubjectViewHolder extends  RecyclerView.ViewHolder{

        TextView title;
        ImageView imageView;
        // FloatingActionButton floatingActionButton;

        public SubjectViewHolder(View itemView) {
            super(itemView);
            title = (TextView)itemView.findViewById(R.id.title);
            imageView = (ImageView) itemView.findViewById(R.id.imageViewPublikasi);
            // floatingActionButton = (FloatingActionButton)itemView.findViewById(R.id.buttonDowmnload);

        }
    }
}
