package com.virtualbox.torchick.rog.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.virtualbox.torchick.rog.MainActivity;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.instance.Deskripsi;
import com.virtualbox.torchick.rog.instance.TurunanVariabel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DaftarTurunanVariabelActivity extends AppCompatActivity {
    private String Satker, Key;
    private String Id_var, Judul_tabel, Notes;
    private ImageView imageView;
    private Button btn_next;
    private CheckBox select_all;
    ListView turvarListView;
    private String turVarParam="";
    private List<TurunanVariabel> turvarListAll = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        Intent intent=getIntent();
        this.Id_var = intent.getStringExtra("id_variabel");
        this.Judul_tabel = intent.getStringExtra("judul_tabel");
        this.Notes = intent.getStringExtra("notes");
        ActionBar ab = getSupportActionBar();
        ab.setDisplayShowHomeEnabled(true);
        ab.setDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.turunanvariabelactivity_main);
        setTitle("Turunan Variabel");
        turvarListView=(ListView) findViewById(R.id.listTurunanVariabel);
        imageView = (ImageView) findViewById(R.id.imageViewLoading);
        btn_next = (Button) findViewById(R.id.btn_next);
        btn_next.setVisibility(View.GONE);
        Glide.with(DaftarTurunanVariabelActivity.this)
                .load(R.drawable.load)
                .into(imageView);
        select_all = (CheckBox) findViewById(R.id.checkall);
        select_all.setVisibility(View.GONE);
        select_all.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(select_all.isChecked())
                {
                    for ( int i=0; i < turvarListView.getCount(); i++) {
                        turvarListView.setItemChecked(i, true);
                    }
                }
                if(!select_all.isChecked())
                {
                    for ( int i=0; i < turvarListView.getCount(); i++) {
                        turvarListView.setItemChecked(i, false);
                    }
                }

            }
        });
        getTurunanVariabel();
    }

    private void getTurunanVariabel() {

        Satker = MainActivity.SATKER;
        Key = MainActivity.KEY;

        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=turvar&var="+this.Id_var+"&domain="+Satker+"&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject alldata = new JSONObject(response);
                            String des = alldata.getString("data");
                            TextView size = findViewById(R.id.size);
                            LinearLayout turvarLinierLayout=findViewById(R.id.turvarLinierLayout);
                            if(des.matches("")) {
                                turvarLinierLayout.setGravity(Gravity.CENTER);
                                turvarListView.setVisibility(View.GONE);
                                select_all.setVisibility(View.GONE);
                                size.setText("Tidak memiliki turunan variabel");
                            }else {
                                size.setVisibility(View.GONE);
                                turvarLinierLayout.setGravity(Gravity.TOP);
                                JSONArray data = alldata.getJSONArray("data");
                                JSONObject deskripsi = data.getJSONObject(0);

                                GsonBuilder builder = new GsonBuilder();
                                Gson gson = builder.create();

                                Deskripsi desc = gson.fromJson(deskripsi.toString(), Deskripsi.class);
                                for (int i = 1; i <= Integer.valueOf(desc.getPages()); i++) {
                                    getDaftarTurVarByPage(String.valueOf(i));
                                }

                                select_all.setVisibility(View.VISIBLE);
                            }
                            imageView.setVisibility(View.GONE);
                            btn_next.setVisibility(View.VISIBLE);
                        } catch (JSONException e) {
                            Toast.makeText(DaftarTurunanVariabelActivity.this,"error",Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        PubSingleton.getmInstance(DaftarTurunanVariabelActivity.this).addToRequestQueue(stringRequest);
    }

    private void getDaftarTurVarByPage(final String page) {

        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=turvar&var="+this.Id_var+"&page="+page+"&domain="+Satker+"&key="+Key;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject alldata = new JSONObject(response);
                            JSONArray data = alldata.getJSONArray("data");
                            JSONArray turvar = data.getJSONArray(1);
                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();
                            List<TurunanVariabel> periodeList = Arrays.asList(gson.fromJson(turvar.toString(),TurunanVariabel[].class));
                            turvarListAll.addAll(periodeList);
                            List<String> periodeString = new ArrayList<String>();
                            for(int i=0; i<turvarListAll.size(); i++){
                                periodeString.add(turvarListAll.get(i).getTurvar());
                            }
                            turvarListView.setChoiceMode(turvarListView.CHOICE_MODE_MULTIPLE);
                            turvarListView.setTextFilterEnabled(true);

                            ArrayAdapter<String> adapter = new ArrayAdapter<String>
                                    (DaftarTurunanVariabelActivity.this,
                                            android.R.layout.simple_list_item_multiple_choice,
                                            android.R.id.text1, periodeString);

                            turvarListView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        PubSingleton.getmInstance(DaftarTurunanVariabelActivity.this).addToRequestQueue(stringRequest);


    }


    public void goPeriodeActivity(View v) {
        if(!turvarListAll.isEmpty()) {
            String param = "";
            for (int i = 0; i < turvarListAll.size(); i++) {
                if (turvarListView.isItemChecked(i)) {
                    param += ";" + turvarListAll.get(i).getTurvar_id();
                }
            }
            if (param.isEmpty()) {
                turVarParam = "";
            } else {
                turVarParam = param.substring(1);
            }
        }
        Intent intent = new Intent(v.getContext(), DaftarPeriodeActivity.class);
        intent.putExtra("id_variabel", this.Id_var);
        intent.putExtra("id_turvar", this.turVarParam);
        intent.putExtra("judul_tabel", this.Judul_tabel);
        intent.putExtra("notes", this.Notes);
        v.getContext().startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {
            this.finish();
        } else {
            super.onBackPressed(); //replaced
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}

