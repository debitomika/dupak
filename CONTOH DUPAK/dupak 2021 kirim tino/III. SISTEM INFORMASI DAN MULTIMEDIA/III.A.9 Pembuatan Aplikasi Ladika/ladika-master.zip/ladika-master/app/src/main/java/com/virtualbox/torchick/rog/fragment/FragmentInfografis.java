package com.virtualbox.torchick.rog.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.virtualbox.torchick.rog.adapter.GalleryAdapterWebAPi;
import com.virtualbox.torchick.rog.adapter.PubSingleton;
import com.virtualbox.torchick.rog.instance.Image;
import com.virtualbox.torchick.rog.R;
import com.virtualbox.torchick.rog.adapter.GalleryAdapter;
import com.virtualbox.torchick.rog.instance.ImageWebApi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class FragmentInfografis extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;
    private ArrayList<Image> images = new ArrayList<>();
    private ArrayList<ImageWebApi> imageswebapi = new ArrayList<>();
    private GalleryAdapter mAdapter;
    private GalleryAdapterWebAPi mAdapterWebAPi;
    private RecyclerView recyclerView;
    private String TAG = "infografis";
    private SwipeRefreshLayout swipeRefreshLayout;

    private FrameLayout frameLayout;
    private Button noInternetButton;

    private int currentPage = 1;
    private boolean isLoading = false;

    public FragmentInfografis() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment InfografisFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentInfografis newInstance(String param1, String param2) {
        FragmentInfografis fragment = new FragmentInfografis();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_infografis, container, false);
        //fetchImages();

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);

//        images = new ArrayList<>();
        imageswebapi = new ArrayList<>();
//        mAdapter = new GalleryAdapter(getContext(), images);
        mAdapterWebAPi = new GalleryAdapterWebAPi(getContext(), imageswebapi);

        frameLayout = (FrameLayout) view.findViewById(R.id.frame_layout);
        noInternetButton = (Button) view.findViewById(R.id.no_internet_button);

        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getContext(), 2);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
//        recyclerView.setAdapter(mAdapter);
        recyclerView.setAdapter(mAdapterWebAPi);
        swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swiperefresh);

        recyclerView.addOnItemTouchListener(new GalleryAdapter.RecyclerTouchListener(getContext(), recyclerView, new GalleryAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("images", imageswebapi);
                bundle.putInt("position", position);

                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                SlideshowDialogFragment newFragment = SlideshowDialogFragment.newInstance();
                newFragment.setArguments(bundle);
                newFragment.show(ft, "slideshow");
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!isLoading) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == imageswebapi.size() - 1) {
                        //bottom of list!
//                        loadMore();
//                        isLoading = true;
                        fetchImages2();
                    }
                }
            }
        });

        swipeRefreshLayout.post(new Runnable() {
            @Override
            public void run() {
                fetchImages2();
            }
        });
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                fetchImages2();
            }
        });
        noInternetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchImages2();
            }
        });


    }

    private void fetchImages() {

        //swipeRefreshLayout.setRefreshing(true);
        String server_url = "https://webapps.bps.go.id/sultra/infografis/sisera.json";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {
                            System.out.println("csc1");

                            JSONArray alldata = new JSONArray(response);

                            String stringinfografis = alldata.toString();

                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();

                            List<Image> infografisList = Arrays.asList(gson.fromJson(stringinfografis, Image[].class));

                            images.clear();

                            // add all the messages
                            images.addAll(infografisList);

                            //mAdapter = new GalleryAdapter(getContext(), images);
                            mAdapter.notifyDataSetChanged();
                            frameLayout.setVisibility(View.GONE);
                            swipeRefreshLayout.setRefreshing(false);

                        } catch (JSONException e) {
                            Toast.makeText(getActivity(), "error", Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), "error respon", Toast.LENGTH_LONG).show();
//                frameLayout.setVisibility(View.VISIBLE);
//                swipeRefreshLayout.setRefreshing(false);
            }
        });


        PubSingleton.getmInstance(getContext()).addToRequestQueue(stringRequest);


    }

    private void fetchImages2() {
        if(isLoading){
            return;
        }

        //swipeRefreshLayout.setRefreshing(true);
//        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=infographic&domain=7400&key=1f5ea27aa195656fa79ee36110bda985&page=1";
        isLoading = true;
        swipeRefreshLayout.setRefreshing(true);
        String server_url = "https://webapi.bps.go.id/v1/api/list/?model=infographic&domain=7400&key=1f5ea27aa195656fa79ee36110bda985&page="+currentPage;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, server_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {
                            System.out.println("csc1");

                            JSONObject api_response = new JSONObject(response);
                            JSONArray infographics = api_response.getJSONArray("data").getJSONArray(1);
//                            Toast.makeText(getActivity(), infographics.toString(), Toast.LENGTH_LONG).show();


//                            JSONArray alldata = new JSONArray(response);
//
                            String stringinfografis = infographics.toString();

                            GsonBuilder builder = new GsonBuilder();
                            Gson gson = builder.create();

                            List<ImageWebApi> infografisList = Arrays.asList(gson.fromJson(stringinfografis, ImageWebApi[].class));
//                            Toast.makeText(getActivity(), Arrays.toString(infografisList.toArray()), Toast.LENGTH_LONG).show();
                            Toast.makeText(getActivity(), "New Infographics loaded", Toast.LENGTH_LONG).show();

//                            imageswebapi.clear();

                            // add all the messages
                            imageswebapi.addAll(infografisList);


                            mAdapterWebAPi.notifyDataSetChanged();
                            frameLayout.setVisibility(View.GONE);
                            swipeRefreshLayout.setRefreshing(false);

                            currentPage++;
                            isLoading = false;

                        } catch (JSONException e) {
//                            Toast.makeText(getActivity(), "error", Toast.LENGTH_LONG).show();
                            Toast.makeText(getActivity(), "No more Infographics", Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                            swipeRefreshLayout.setRefreshing(false);
                            isLoading = false;
                        }



                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), "error respon", Toast.LENGTH_LONG).show();
                swipeRefreshLayout.setRefreshing(false);
                isLoading = false;
//                frameLayout.setVisibility(View.VISIBLE);
//                swipeRefreshLayout.setRefreshing(false);
            }
        });


        PubSingleton.getmInstance(getContext()).addToRequestQueue(stringRequest);


    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

}