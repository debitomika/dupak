package com.virtualbox.torchick.rog.instance;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class DeskripsiDinamis {

    @SerializedName("page")
    private String page;
    @SerializedName("pages")
    private String pages;
    @SerializedName("per_page")
    private String per_page;
    @SerializedName("count")
    private String count;
    @SerializedName("total")
    private String total;

    public String getPage() {
        return page;
    }

    public String getPages() {
        return pages;
    }

    public String getPer_page() {
        return per_page;
    }

    public String getCount() {
        return count;
    }

    public String getTotal() {
        return total;
    }




}
