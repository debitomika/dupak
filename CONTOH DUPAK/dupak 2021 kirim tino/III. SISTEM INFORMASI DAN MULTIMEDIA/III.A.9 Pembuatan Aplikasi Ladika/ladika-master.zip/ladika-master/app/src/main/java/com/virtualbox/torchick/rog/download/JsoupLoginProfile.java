package com.virtualbox.torchick.rog.download;


import android.os.AsyncTask;


import org.jsoup.Connection;
import org.jsoup.Jsoup;

import java.io.IOException;


public class JsoupLoginProfile extends AsyncTask<Void, Integer, Void> {


    private String username, password;
    String sessionIdt = "";

    ProfileActivity profileActivity;



    public JsoupLoginProfile(ProfileActivity profileActivity, String Username, String Password) {

        this.profileActivity = profileActivity;
        this.username = Username;
        this.password = Password;

    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();


    }

    @Override
    protected Void doInBackground(Void... params) {

        Connection.Response response = null;

        try {

            response = Jsoup.connect("https://webapi.bps.go.id/consumen/1f5ea27aa195656fa79ee36110bda985")
                    .data("LoginForm[email]", username)
                    .data("LoginForm[password]", password)
                    .data("yt0", "Sign In")
                    .timeout(35000)
                    .userAgent("Mozilla")
                    .method(Connection.Method.POST)
                    .execute();

            //token = response.url().toString().replace("https://webapi.bps.go.id/consumen/consumer/token/","");
            sessionIdt = response.cookie("consumen");

        } catch (IOException e) {


            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void result) {

        profileActivity.afterGetToken(sessionIdt);



    }


}