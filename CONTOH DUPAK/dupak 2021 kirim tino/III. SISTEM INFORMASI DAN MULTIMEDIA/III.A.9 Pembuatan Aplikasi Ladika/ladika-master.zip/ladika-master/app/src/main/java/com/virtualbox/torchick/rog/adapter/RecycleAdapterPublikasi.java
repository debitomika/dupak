package com.virtualbox.torchick.rog.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.virtualbox.torchick.rog.activity.DetailPublikasiActivity;
import com.virtualbox.torchick.rog.instance.Publikasi;

import java.util.ArrayList;
import java.util.List;
import com.virtualbox.torchick.rog.R;
import com.squareup.picasso.Picasso;

/**
 * Created by Yusfil Pulungan on 3/23/2018.
 */

public class RecycleAdapterPublikasi extends RecyclerView.Adapter<RecycleAdapterPublikasi.PublikasiViewHolder> {

    private List<Publikasi> publikasiList = new ArrayList<>();
    private Context mContext;
    View view;
    String satker;

    public RecycleAdapterPublikasi(List<Publikasi> publikasiList,Context context, String satker){

       this.publikasiList = publikasiList;
        this.mContext = context;
        this.satker =satker;
    }


    @Override
    public PublikasiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_publikasi_item,parent,false);

        return new PublikasiViewHolder(view);
    }

    public static String geTkey1(){
        return "5FE882F5E894E5D3070B7607285260220";
    }

    @Override
    public void onBindViewHolder(PublikasiViewHolder holder, int position) {
        holder.issn.setText("ISSN/ISBN : "+ publikasiList.get(position).getIssn());
        holder.rl_date.setText("Release Date : "+ publikasiList.get(position).getRl_date());
        final CharSequence p = publikasiList.get(position).getTitle();
        final String id_publikasi = publikasiList.get(position).getPub_id();
        holder.title.setText(p);

        Picasso.with(mContext)
                .load(publikasiList.get(position).getCover())
                .placeholder(R.drawable.load)
                .error(R.drawable.bps)
                .into(holder.imageView);

        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DetailPublikasiActivity.class);
                intent.putExtra("id_publikasi", id_publikasi);
                v.getContext().startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        return publikasiList.size();
    }

    public static class PublikasiViewHolder extends  RecyclerView.ViewHolder{

        TextView issn, rl_date,title;
        ImageView imageView;
        // FloatingActionButton floatingActionButton;

        public PublikasiViewHolder(View itemView) {
            super(itemView);

            rl_date = (TextView)itemView.findViewById(R.id.rl_date);
            issn = (TextView)itemView.findViewById(R.id.issn);


            title = (TextView)itemView.findViewById(R.id.title);
            imageView = (ImageView) itemView.findViewById(R.id.imageViewPublikasi);
            // floatingActionButton = (FloatingActionButton)itemView.findViewById(R.id.buttonDowmnload);

        }
    }
}
